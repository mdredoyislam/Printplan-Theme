<?php
namespace Resox\Helper\Elementor;

/**
 * The Menu handler class
 */

class Scripts {










	private $prefix = 'resox';

	public function __construct() {
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'resox_core_required_script' ) );
		add_action( 'wp_head', array( $this, 'widget_assets_css' ) );
		add_action( 'wp_footer', array( $this, 'widget_scripts' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'widget_editor_scripts' ) );
	}

	public function resox_core_required_script( $screen ) {

	}
	public function widget_assets_css() {
		wp_enqueue_style( 'elementor-custom-style', Resox_CORE_ASSETS . '/elementor/css/style.css', true );
	}

	public function widget_scripts() {
		wp_enqueue_script( 'gallery_js', Resox_CORE_ASSETS . '/elementor/js/gallery.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'countbox_js', Resox_CORE_ASSETS . '/elementor/js/countbox.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'testimonial_js', Resox_CORE_ASSETS . '/elementor/js/testimonial.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'client_js', Resox_CORE_ASSETS . '/elementor/js/client.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'countbar_js', Resox_CORE_ASSETS . '/elementor/js/countbar.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'bannerslider_js', Resox_CORE_ASSETS . '/elementor/js/bannerslider.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'progresscircle_js', Resox_CORE_ASSETS . '/elementor/js/progresscircle.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'testimonial_js', Resox_CORE_ASSETS . '/elementor/js/testimonial.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'service_js', Resox_CORE_ASSETS . '/elementor/js/service.js', array( 'jquery' ), time(), true );
		wp_enqueue_script( 'team_js', Resox_CORE_ASSETS . '/elementor/js/team.js', array( 'jquery' ), time(), true );

	}

	public function widget_editor_scripts() {
	}
}
