<?php
namespace Resox\Helper\Elementor;

use Elementor\Plugin;

class Element {




	public function __construct() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ) );
	}
	public function widgets_registered() {

		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Banner_Slider() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Feature() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_About() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Client() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Proudly() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Feature_Two() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Testimonial() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Startup() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Blog() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Gallery() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Call_To_Action() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Welcome() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Certified() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_About_Two() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_About_Three() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Faq() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Team() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Newsletter() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Startup_Section_Two() );

		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Service() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Service_Single() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Team_Details() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Our_Certification() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Sidebar_Support() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Contact() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Google_Map_Contact() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Footer() );
		Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Resox_Team_Slider() );

	}
	function add_elementor_widget_categories( $elements_manager ) {
		$elements_manager->add_category(
			'resox',
			array(
				'title' => __( 'Resox', 'resox-core' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}
}
