<?php
namespace Resox\Helper\Elementor;

class Icon {

	public function __construct() {
		add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'custom_icon' ) );
	}

	function custom_icon( $array ) {
		$plugin_url = plugins_url();

		return array(
			'custom-icon' => array(
				'name'          => 'custom-icon',
				'label'         => 'Resox Icon',
				'url'           => '',
				'enqueue'       => array(
					$plugin_url . '/resox-core/assets/elementor/icon/flaticon-icon.css',
				),
				'prefix'        => '',
				'displayPrefix' => '',
				'labelIcon'     => 'resox-icon',
				'ver'           => '',
				'fetchJson'     => $plugin_url . '/resox-core/assets/elementor/icon/js/regular.js',
				'native'        => 1,
			),
		);
	}
}
