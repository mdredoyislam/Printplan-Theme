<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_About extends Widget_Base {

	public function get_name() {
		return 'resox_about';
	}

	public function get_title() {
		return esc_html__( 'Resox About', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);
		$this->add_control(
			'layout_style',
			array(
				'label'   => __( 'Layout Style', 'resox' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => array(
					'style_1' => __( '1', 'resox' ),
					'style_2' => __( '2', 'resox' ),
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'  => 'background',
				'label' => esc_html__( 'Background', 'resox' ),
				'types' => array( 'classic', 'gradient' ),

			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Clinic Introduction', 'resox' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Welcome to Physiotherapy & Chiroparctor Clinic', 'resox' ),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'icon',
			array(
				'label' => esc_html__( 'Icon', 'resox' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'message_text',
			array(
				'label'   => esc_html__( 'Message Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Get your lifestyle back', 'resox' ),
			)
		);

		$this->add_control(
			'author_image',
			array(
				'label'   => esc_html__( 'Author Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'author_signature',
			array(
				'label'   => esc_html__( 'Author Signature', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox' ),
			)
		);
		$this->add_control(
			'image_1',
			array(
				'label'     => esc_html__( 'Image 1', 'resox' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'condition' => array( 'layout_style' => 'style_2' ),

			)
		);
		$this->add_control(
			'image_2',
			array(
				'label'     => esc_html__( 'Image 2', 'resox' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'condition' => array( 'layout_style' => 'style_2' ),

			)
		);
		$this->add_control(
			'image_3',
			array(
				'label'     => esc_html__( 'Image 3', 'resox' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'condition' => array( 'layout_style' => 'style_2' ),

			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'item_title',
			array(
				'label' => esc_html__( 'Title', 'resox' ),
				'type'  => Controls_Manager::TEXT,
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label' => esc_html__( 'Content', 'resox' ),
				'type'  => Controls_Manager::TEXT,
			)
		);
		$this->add_control(
			'items',
			array(
				'label'     => esc_html__( 'Repeater List', 'resox' ),
				'type'      => Controls_Manager::REPEATER,
				'fields'    => $repeater->get_controls(),
				'default'   => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
				'condition' => array( 'layout_style' => 'style_2' ),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];
		$public_title_tag     = $settings['public_title_tag'];
		$tagline      = $settings['tagline'];
		$title        = $settings['title'];
		$content      = $settings['content'];

		if ( $layout_style == 'style_2' ) {
			$image_1 = ( $settings['image_1']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image_1']['id'], 'full' ) : $settings['image_1']['url'];
			if ( ! empty( $image_1 ) ) {
				$this->add_render_attribute( 'image_1', 'src', $image_1 );
				$this->add_render_attribute( 'image_1', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image_1'] ) );
				$this->add_render_attribute( 'image_1', 'title', \Elementor\Control_Media::get_image_title( $settings['image_1'] ) );
					$settings['image_1_size'] = 'full';
					$image_1_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_1' );

			}

			$image_2 = ( $settings['image_2']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image_2']['id'], 'full' ) : $settings['image_2']['url'];
			if ( ! empty( $image_2 ) ) {
				$this->add_render_attribute( 'image_2', 'src', $image_1 );
				$this->add_render_attribute( 'image_2', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image_2'] ) );
				$this->add_render_attribute( 'image_2', 'title', \Elementor\Control_Media::get_image_title( $settings['image_2'] ) );
					$settings['image_2_size'] = 'full';
					$image_2_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_2' );

			}

			$image_3 = ( $settings['image_3']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image_3']['id'], 'full' ) : $settings['image_3']['url'];
			if ( ! empty( $image_3 ) ) {
				$this->add_render_attribute( 'image_3', 'src', $image_1 );
				$this->add_render_attribute( 'image_3', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image_3'] ) );
				$this->add_render_attribute( 'image_3', 'title', \Elementor\Control_Media::get_image_title( $settings['image_3'] ) );
					$settings['image_3_size'] = 'full';
					$image_3_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_3' );

			}
		}

		$icon         = $settings['icon'];
		$message_text = $settings['message_text'];
		$author_image = ( $settings['author_image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['author_image']['id'], 'full' ) : $settings['author_image']['url'];
		if ( ! empty( $author_image ) ) {
			$this->add_render_attribute( 'author_image', 'src', $author_image );
			$this->add_render_attribute( 'author_image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['author_image'] ) );
			$this->add_render_attribute( 'author_image', 'title', \Elementor\Control_Media::get_image_title( $settings['author_image'] ) );
			$settings['author_image_size'] = 'full';
			$author_image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'author_image' );

		}
		$author_signature = ( $settings['author_signature']['id'] != '' ) ? wp_get_attachment_image_url( $settings['author_signature']['id'], 'full' ) : $settings['author_signature']['url'];
		if ( ! empty( $author_signature ) ) {
			$this->add_render_attribute( 'author_signature', 'src', $author_signature );
			$this->add_render_attribute( 'author_signature', 'alt', \Elementor\Control_Media::get_image_alt( $settings['author_signature'] ) );
			$this->add_render_attribute( 'author_signature', 'title', \Elementor\Control_Media::get_image_title( $settings['author_signature'] ) );
			$settings['author_signature_size'] = 'full';
			$author_signature_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'author_signature' );

		}
		?>
		<?php if ( $layout_style == 'style_1' ) { ?>
<section class="about-section sec-pad">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-xl-7 col-lg-12 col-md-12 content-column">
				<div id="content_block_1">
					<div class="content-box">
						<div class="sec-title">
							<p><?php echo $tagline; ?></p>
							<<?php echo $public_title_tag; ?> class="typo-title-text">
								<?php echo $title; ?>
							</<?php echo $public_title_tag; ?>>
						</div>
						<?php echo $content; ?>
						<div class="inner-box clearfix">
							<div class="inner">
								<div class="icon-box">
									<?php \Elementor\Icons_Manager::render_icon( ( $icon ), array( 'aria-hidden' => 'true' ) ); ?>
								</div>
								<h4><?php echo $message_text; ?></h4>
							</div>
							<div class="author">
								<figure class="author-thumb"><?php echo $author_image_html; ?></figure>
								<figure class="signature"><?php echo $author_signature_html; ?></figure>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		<?php } elseif ( $layout_style == 'style_2' ) { ?>
<section class="about-style-three">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-lg-6 col-md-12 col-sm-12 image-column">
				<div class="image-box">
					<div class="row clearfix">
						<div class="col-lg-6 col-md-6 col-sm-12 column">
							<figure class="image mb-30"><?php echo $image_1_html; ?></figure>
							<figure class="image"><?php echo $image_2_html; ?></figure>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 column">
							<figure class="image"><?php echo $image_3_html; ?></figure>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 content-column">
				<div id="content_block_8">
					<div class="content-box ml-70">
						<div class="sec-title">
							<p><?php echo $tagline; ?></p>
							<h2><?php echo $title; ?></h2>
						</div>
						<div class="text">
							<?php echo $content; ?>
						</div>
						<div class="inner-box clearfix">

							<?php
									$i = 1;
							foreach ( $settings['items'] as $item ) {

								$item_title   = $item['item_title'];
								$item_content = $item['item_content'];

								?>
							<div class="single-item">
								<h5><?php echo $item_title; ?></h5>
								<?php echo $item_content; ?>
							</div>

								<?php
									$i++;
							}
							?>
						</div>
						<div class="author-box">
							<figure class="author-thumb"><?php echo $author_image_html; ?></figure>
							<figure class="signature"><?php echo $author_signature_html; ?></figure>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
			<?php
		}
	}

	protected function _content_template() {
	}
}
