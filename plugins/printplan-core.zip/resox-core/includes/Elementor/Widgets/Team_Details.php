<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Team_Details extends Widget_Base {


	public function get_name() {
		return 'resox_team_details';
	}

	public function get_title() {
		return esc_html__( 'Team Details', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'name',
			array(
				'label'       => esc_html__( 'Name', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Dr. Kevin Martin', 'resox-core' ),
			)
		);

		$this->add_control(
			'designation',
			array(
				'label'       => esc_html__( 'Designation', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Senior Therapist', 'resox-core' ),
			)
		);

		$this->add_control(
			'social_list',
			array(
				'label'       => esc_html__( 'Social List', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox-core' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox-core' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'       => esc_html__( 'Title', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$repeater->add_control(
			'item_percent',
			array(
				'label'       => esc_html__( 'Percent', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '98%', 'resox-core' ),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$image    = ( $settings['image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image']['id'], 'full' ) : $settings['image']['url'];
		if ( ! empty( $image ) ) {
			$this->add_render_attribute( 'image', 'src', $image );
			$this->add_render_attribute( 'image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image'] ) );
			$this->add_render_attribute( 'image', 'title', \Elementor\Control_Media::get_image_title( $settings['image'] ) );
			$settings['image_size'] = 'full';
			$image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image' );
		}
		$name        = $settings['name'];
		$designation = $settings['designation'];
		$social_list = $settings['social_list'];
		$content     = $settings['content'];
		$public_title_tag     = $settings['public_title_tag'];
		?> <section class="team-details">
			<div class="auto-container">
				<div class="row clearfix">
					<div class="col-lg-6 col-md-12 col-sm-12 image-column">
						<figure class="image-box"><?php echo $image_html; ?></figure>
					</div>
					<div class="col-lg-6 col-md-12 col-sm-12 content-column">
						<div class="team-details-content ml-70">
							<div class="upper-box">
								<<?php echo $public_title_tag; ?> class="typo-title-text">
									<?php echo $name; ?>
								</<?php echo $public_title_tag; ?>>
								<span class="designation"><?php echo $designation; ?></span>

								<?php echo $social_list; ?>

							</div>
							<div class="text">
								<p><?php echo $content; ?></p>
							</div>
							<div class="progress-inner">

								<?php
								$i = 1;
								foreach ( $settings['items'] as $item ) {
									$item_title   = $item['item_title'];
									$item_percent = $item['item_percent'];
									?>
								 <div class="progress-box">
										<h5><?php echo $item_title; ?></h5>
										<div class="bar">
											<div class="bar-inner count-bar" data-percent="<?php echo $item_percent; ?>"></div>
											<div class="count-text"><?php echo $item_percent; ?></div>
										</div>
									</div> 
									<?php
									$i++;
								}
								?>


							</div>
						</div>
					</div>
				</div>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
