<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;

class Resox_Sidebar_Support extends Widget_Base {

	public function get_name() {
		return 'resox_sidebar_support';
	}

	public function get_title() {
						return esc_html__( 'Resox Sidebar Support', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Need Help?', 'resox' ),
			)
		);

		$this->add_control(
			'bg_img',
			array(
				'label'   => esc_html__( 'Background Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'content',
			array(
				'label'   => esc_html__( 'Content', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Speak with a human to filling out a form? call corporate office and we will connect you with a team member who can help.', 'resox' ),
			)
		);

		$this->add_control(
			'phone',
			array(
				'label'   => esc_html__( 'Phone Number', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '6660009999', 'resox' ),
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'   => esc_html__( 'Button Text', 'resox-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Book Appointment', 'resox-core' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->end_controls_section();

		resox_public_header_control( $this, 'h4' );

		resox_public_content_control( $this );
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$bg_img   = ( $settings['bg_img']['id'] != '' ) ? wp_get_attachment_image_url( $settings['bg_img']['id'], 'full' ) : $settings['bg_img']['url'];

		// From Public Header
		$public_title_tag = $settings['public_title_tag'];

		$heading = $settings['heading'];
		$this->add_render_attribute( 'heading', 'class', 'typo-title-text' );
		$this->add_inline_editing_attributes( 'heading', 'none' );

		$content = $settings['content'];
		$this->add_render_attribute( 'content', 'class', 'typo-content-text' );
		$this->add_inline_editing_attributes( 'content', 'none' );
		// From Public Header
		$phone        = $settings['phone'];
		$tel          = str_replace( ' ', '', $phone );
		$button_title = $settings['button_title'];
		$button_link  = $settings['button_link']['url'];
		if ( ! empty( $button_link ) ) {
			$this->add_render_attribute( 'button_link', 'href', $button_link );
			if ( ! empty( $settings['button_link']['is_external'] ) ) {
				$this->add_render_attribute( 'button_link', 'target', '_blank' );
			}

			if ( ! empty( $settings['button_link']['nofollow'] ) ) {
				$this->add_render_attribute( 'button_link', 'rel', 'nofollow' );
			}
		}
		?>
<!-- Header -->
<div class="service-sidebar">
	<div class="sidebar-widget sidebar-support" <?php if ( $bg_img ) : ?>
		style="background-image: url(<?php echo $bg_img; ?>);" <?php endif; ?>>
		<div class="widget-content">
			<!-- Title -->
			<<?php echo $public_title_tag; ?> <?php echo $this->get_render_attribute_string( 'heading' ); ?>>
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
			<!-- Title -->
			<p <?php echo $this->get_render_attribute_string( 'content' ); ?>><?php echo $content; ?></p>
			<?php
			if ( $phone ) :
				?>
			<h3><a href="tel:<?php echo $tel; ?>"><?php echo $phone; ?></a></h3><?php endif; ?>
			<?php if ( $button_title ) : ?>
			<div class="btn-box"><a <?php echo $this->get_render_attribute_string( 'button_link' ); ?>
					class="theme-btn-one"><?php echo $button_title; ?></a></div>
			<?php endif; ?>
		</div>
	</div>
</div>
<!-- Header -->
		<?php
	}

	protected function _content_template() {
	}
}
