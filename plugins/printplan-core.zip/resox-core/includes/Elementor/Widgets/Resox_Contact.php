<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use \Resox\Helper\Elementor\Settings\Header;

class Resox_Contact extends Widget_Base {


	public function get_name() {
		return 'resox_contact';
	}

	public function get_title() {
		return esc_html__( 'Resox Contact', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);

		$this->add_control(
			'tag_line',
			array(
				'label'       => esc_html__( 'Tag Line', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Contact with us', 'resox-core' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Leave Us a Message', 'resox-core' ),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.', 'resox-core' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);
		$this->add_control(
			'contact_cf7',
			array(
				'label'   => esc_html__( 'Select Contact Form', 'firbrigs-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => Header::getContactForm7Posts(),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'Info Contact', 'resox-core' ),
			)
		);
		$this->add_control(
			'info_content',
			array(
				'label'       => esc_html__( 'Info Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox-core' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$this->add_control(
			'info_bg_image',
			array(
				'label'   => esc_html__( 'Info Bg Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Button Title', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Book Appointment', 'resox-core' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox-core' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$repeater->add_control(
			'item_contact_info',
			array(
				'label'       => esc_html__( 'Contact Info', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '', 'resox-core' ),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render() {
		$settings      = $this->get_settings_for_display();
		$tag_line      = $settings['tag_line'];
		$heading       = $settings['heading'];
		$public_title_tag     = $settings['public_title_tag'];
		$content       = $settings['content'];
		$info_content  = $settings['info_content'];
		$info_bg_image = ( $settings['info_bg_image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['info_bg_image']['id'], 'full' ) : $settings['info_bg_image']['url'];

		$button_title = $settings['button_title'];
		$button_link  = $settings['button_link']['url'];
		if ( ! empty( $button_link ) ) {
			$this->add_render_attribute( 'button_link', 'href', $button_link );
			if ( ! empty( $settings['button_link']['is_external'] ) ) {
				$this->add_render_attribute( 'button_link', 'target', '_blank' );
			}

			if ( ! empty( $settings['button_link']['nofollow'] ) ) {
				$this->add_render_attribute( 'button_link', 'rel', 'nofollow' );
			}
		}
		?> 
		<section class="contact-section sec-pad">
			<div class="auto-container">
				<div class="title-inner clearfix">
					<div class="sec-title pull-left">
						<p><?php echo $tag_line; ?></p>
						<<?php echo $public_title_tag; ?> class="typo-title-text">
							<?php echo $heading; ?>
						</<?php echo $public_title_tag; ?>>
					</div>
					<div class="text pull-right">
						<p><?php echo $content; ?></p>
					</div>
				</div>
				<div class="row clearfix">
					<div class="col-lg-4 col-md-6 col-sm-12 info-column">
						<div class="info-inner" style="background-image: url(<?php echo esc_attr( $info_bg_image ); ?>);">
							<div class="content-box">
								<div class="text">
									<p><?php echo $info_content; ?></p>
								</div>
								<ul class="info-list clearfix">
									<?php
									$i = 1;
									foreach ( $settings['items'] as $item ) {
										$item_icon         = $item['item_icon'];
										$item_contact_info = $item['item_contact_info'];
										?>
									 <li>
											<?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?>
											<?php echo $item_contact_info; ?>
										</li> 
										<?php
										$i++;
									}
									?>


								</ul>
								<div class="btn-box">
									<a <?php echo $this->get_render_attribute_string( 'button_link' ); ?> class="theme-btn-one"><?php echo $button_title; ?></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-8 col-md-6 col-sm-12 form-column">
						<div class="form-inner">

						<?php
						if ( $settings['contact_cf7'] ) :
							echo do_shortcode( '[contact-form-7 id="' . $settings['contact_cf7'] . '"]' );
									endif;
						?>

						</div>
					</div>

				</div>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
