<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Elementor\Core\Schemes;

class Resox_Banner_Slider extends Widget_Base {



	public function get_name() {
		return 'resox_banner_slider';
	}

	public function get_title() {
		return esc_html__( 'Resox Banner Slider', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'bannerslider_js' );
	}


	protected function _register_controls() {

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox-core' ),
			)
		);
		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),

				),
				'default' => 'style_1',

			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'item_background_image',
			array(
				'label'   => esc_html__( 'Background Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);
		$repeater->add_control(
			'item_subheading',
			array(
				'label'       => esc_html__( 'Sub Heading', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Welcome to physiotherapy clinic', 'resox-core' ),
			)
		);
		$repeater->add_control(
			'item_heading',
			array(
				'label'       => esc_html__( 'Heading', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'We’re Here to Save Lives and Properties', 'resox-core' ),
			)
		);
		$repeater->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'Html Tag Heading', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'h1'   => esc_html__( 'H1', 'resox-core' ),
					'h2'   => esc_html__( 'H2', 'resox-core' ),
					'h3'   => esc_html__( 'H3', 'resox-core' ),
					'h4'   => esc_html__( 'H4', 'resox-core' ),
					'h5'   => esc_html__( 'H5', 'resox-core' ),
					'h6'   => esc_html__( 'H6', 'resox-core' ),
					'div'  => esc_html__( 'div', 'resox-core' ),
					'span' => esc_html__( 'span', 'resox-core' ),
					'p'    => esc_html__( 'p', 'resox-core' ),
				),
				'default' => 'h1',

			)
		);
		$repeater->add_control(
			'item_desc',
			array(
				'label'       => esc_html__( 'Content', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
			)
		);
		$repeater->add_control(
			'item_button_name',
			array(
				'label'       => esc_html__( 'Button Name', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discover More', 'resox-core' ),
			)
		);

		$repeater->add_control(
			'item_button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'text_style_section',
			array(
				'label' => __( 'Text Style', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'resox-core' ),
				'scheme'   => Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .banner_section',
			)
		);
		$this->end_controls_section();
	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];
		if ( $layout_style == 'style_2' ) {
			$layout_style = 'style-two';
		} else {
			$layout_style = 'centred';
		}
		?> 
		<section class="banner-section <?php echo esc_attr( $layout_style ); ?>">
			<div class="banner-carousel owl-theme owl-carousel owl-dots-none nav-style-one">
		<?php
		$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_background_image = ( $item['item_background_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_background_image']['id'], 'full' ) : $item['item_background_image']['url'];

			$item_subheading  = $item['item_subheading'];
			$item_heading     = $item['item_heading'];
			$html_tag         = $item['html_tag'];
			$item_desc        = $item['item_desc'];
			$item_button_name = $item['item_button_name'];

			$item_menu_link     = $item['item_button_link'];
			$item_menu_target   = $item['item_button_link']['is_external'] ? ' target="_blank"' : '';
			$item_menu_nofollow = $item['item_button_link']['nofollow'] ? ' rel="nofollow"' : '';
			?>
	
				<div class="slide-item">
					<div class="image-layer" style="background-image:url(<?php echo esc_url( $item_background_image ); ?>)"></div>
					<div class="auto-container">
						<div class="content-box">
			<?php if ( $item_subheading ) { ?>
							<h6><?php echo $item_subheading; ?></h6>
			<?php } ?>
							<<?php echo $html_tag; ?> class="banner_section"><?php echo $item_heading; ?></<?php echo $html_tag; ?>>
			<?php if ( $item_desc ) { ?>
							<p><?php echo $item_desc; ?></p>
			<?php } ?>
							<div class="btn-box">
								<a href="<?php echo esc_url( $item_menu_link['url'] ); ?>" <?php echo $item_menu_target . ' ' . $item_menu_nofollow; ?> class="theme-btn-one"><?php echo $item_button_name; ?></a>
							</div>
						</div>  
					</div>
				</div> 
			<?php
			$i++;
		}
		?>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
