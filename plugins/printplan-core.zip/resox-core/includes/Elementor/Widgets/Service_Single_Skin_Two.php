<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Skin_Base;
use Elementor\Repeater;

class Skin_Single_Two extends Skin_Base {
	public function __construct( Widget_Base $parent ) {
		$this->parent = $parent;
		$this->_register_controls_actions();
		add_action( 'elementor/element/resox_service_single/general/before_section_end', array( $this, 'register_controls' ) );
		add_action( 'elementor/element/resox_service_single/general/after_section_end', array( $this, 'update_controls' ) );
	}
	public function get_id() {
		return 'layout_3';
	}

	public function get_title() {
		return __( 'Layout 3', 'ele-layout_3-skin' );
	}

	protected function _register_controls_actions() {
		parent::_register_controls_actions();
	}

	public function update_controls( Widget_Base $widget ) {
		$this->parent = $widget;
		$this->parent->update_control(
			'items',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '==',
							'value'    => 'layout_3',
						),
					),
				),
			)
		);
		$this->parent->update_control(
			'highlight_label',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '==',
							'value'    => 'layout_3',
						),
					),
				),
			)
		);
		$this->parent->update_control(
			'icon',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'layout_2',
						),
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'layout_3',
						),
					),
				),
			)
		);
	}

	public function register_controls( Widget_Base $widget ) {

		$this->parent->start_injection(
			array(
				'type' => 'section',
				'at'   => 'end',
				'of'   => 'general',
			)
		);

		// Control Here

		$this->parent->end_injection();

	}

	public function render() {
		$settings             = $this->parent->get_settings_for_display();
		$public_title_tag     = $settings['public_title_tag'];
		$heading              = $settings['heading'];
		$content              = $settings['content'];
		$content_two          = $settings['content_two'];
		$highlight_label      = $settings['highlight_label'];
		$temp_highlight_label = '<span>' . $highlight_label . '</span>';
		$content_two          = str_replace( $highlight_label, $temp_highlight_label, $content_two );
		$bg_img               = ( $settings['bg_img']['id'] != '' ) ? wp_get_attachment_image_url( $settings['bg_img']['id'], 'full' ) : $settings['bg_img']['url'];
		?>

<!-- service-page-section -->
<div class="service-details-content">
	<div class="content-two">
		<div class="text">
			<!-- Title -->
			<<?php echo $public_title_tag; ?> class="typo-title-text">
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
			<!-- Title -->
			<p class="typo-content-text"><?php echo $content; ?></p>
		</div>
		<div class="inner-box" 
		<?php
		if ( $bg_img ) :
			?>
			 style="background-image: url(<?php echo $bg_img; ?>);" <?php endif; ?>>
			<ul class="list-item clearfix">
				<?php
				$i = 1;
				foreach ( $settings['items'] as $item ) {
					$item_content = $item['item_content'];
					?>
				<li><?php echo $item_content; ?></li>
					<?php
					$i++;
				}
				?>
			</ul>
		</div>
		<div class="text">
			<p class="typo-content-text"><?php echo $content_two; ?></p>
		</div>
	</div>
</div>


<!-- service-page-section end -->
		<?php
	}

}
