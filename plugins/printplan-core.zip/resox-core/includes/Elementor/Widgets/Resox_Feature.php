<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Elementor\Core\Schemes;

class Resox_Feature extends Widget_Base {



	public function get_name() {
		return 'resox_feature';
	}

	public function get_title() {
		return esc_html__( 'Resox Feature', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'item', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Experienced Therapists', 'resox' ),
			)
		);
		$repeater->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'Html Tag', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'h1'   => esc_html__( 'H1', 'resox-core' ),
					'h2'   => esc_html__( 'H2', 'resox-core' ),
					'h3'   => esc_html__( 'H3', 'resox-core' ),
					'h4'   => esc_html__( 'H4', 'resox-core' ),
					'h5'   => esc_html__( 'H5', 'resox-core' ),
					'h6'   => esc_html__( 'H6', 'resox-core' ),
					'div'  => esc_html__( 'div', 'resox-core' ),
					'span' => esc_html__( 'span', 'resox-core' ),
					'p'    => esc_html__( 'p', 'resox-core' ),
				),
				'default' => 'h4',

			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Lorem ipsum is fre dolor sit amet cectetuer adipiscing elit, sed diam nonummy nibh.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$repeater->add_control(
			'item_button',
			array(
				'label'   => esc_html__( 'Button Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Read More', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_button_link',
			array(
				'label'   => esc_html__( 'Button Link', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '#', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'text_style_section',
			array(
				'label' => __( 'Text Style', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'resox-core' ),
				'scheme'   => Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .feature_heading',
			)
		);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?> 
<section class="feature-section">
  <div class="outer-container clearfix">
		<?php
		$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_title       = $item['item_title'];
			$item_content     = $item['item_content'];
			$item_button      = $item['item_button'];
			$item_button_link = $item['item_button_link'];
			$item_icon        = $item['item_icon'];
			$html_tag        = $item['html_tag'];
			?>
				   
					<div class="feature-block-one">
						<div class="inner-box">
							<div class="icon-box">
			<?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?>
							</div>
							<div class="inner">
							<<?php echo $html_tag; ?> class="feature_heading"><?php echo $item_title; ?></<?php echo $html_tag; ?>>
							<p><?php echo $item_content; ?></p>
							<a href="<?php echo $item_button_link; ?>"><i class="fas fa-chevron-circle-right"></i><?php echo $item_button; ?></a>
							</div>
						</div>
					</div> 
			<?php
			$i++;
		}
		?>
  </div>
</section> 
		<?php
	}

	protected function _content_template() {
	}
}




