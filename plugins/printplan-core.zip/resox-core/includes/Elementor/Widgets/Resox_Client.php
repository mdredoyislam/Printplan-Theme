<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Client extends Widget_Base {









	public function get_name() {
		return 'resox_client';
	}

	public function get_title() {
		return esc_html__( 'Resox Client', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'client_js' );
	}
	

	protected function _register_controls() {

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox-core' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__( 'Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);
		$this->add_control(
			'extra_class',
			array(
				'label' => esc_html__( 'Extra Class', 'resox' ),
				'type'  => Controls_Manager::TEXT,
			)
		);
		$this->end_controls_section();
	}
	protected function render() {
		$settings    = $this->get_settings_for_display();
		$extra_class = $settings['extra_class'];
		$section_class = $extra_class ?? '';
		?>
		<section class="clients-section <?php echo esc_attr( $section_class ); ?>">
			<div class="auto-container">
				<div class="clients-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
		<?php
		$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_image = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
			if ( ! empty( $item_image ) ) {
				$this->add_render_attribute( 'item_image', 'src', $item_image );
				$this->add_render_attribute( 'item_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_image'] ) );
				$this->add_render_attribute( 'item_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_image'] ) );
				$item['item_image_size'] = 'full';
				$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_image' );
			}
			$item_menu_link     = $item['item_link'];
			$item_menu_target   = $item['item_link']['is_external'] ? ' target="_blank"' : '';
			$item_menu_nofollow = $item['item_link']['nofollow'] ? ' rel="nofollow"' : '';
			?>
					 
					<figure class="clients-logo-box">
						<a href="<?php echo esc_url( $item_menu_link['url'] ); ?>" <?php echo $item_menu_target . ' ' . $item_menu_nofollow; ?>><?php echo $item_image_html; ?></a>
					</figure> 
			<?php
			$i++;
		}
		?>
				</div>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
