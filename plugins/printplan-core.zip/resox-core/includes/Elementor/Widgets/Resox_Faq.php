<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Faq extends Widget_Base {

	public function get_name() {
		return 'resox_faq';
	}

	public function get_title() {
		return esc_html__( 'Resox Faq', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);

		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),

				),
				'default' => 'style_1',

			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'      => esc_html__( 'Tagline', 'resox' ),
				'type'       => Controls_Manager::TEXT,
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'layout_style',
							'operator' => '==',
							'value'    => 'style_1',
						),
					),
				),
				'default'    => __( 'Your Quesiton', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'      => esc_html__( 'Heading', 'resox' ),
				'type'       => Controls_Manager::TEXT,
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'layout_style',
							'operator' => '==',
							'value'    => 'style_1',
						),
					),
				),
				'default'    => __( 'Have any Quesiton', 'resox' ),
			)
		);

		$this->add_control(
			'image',
			array(
				'label'      => esc_html__( 'Image', 'resox' ),
				'type'       => Controls_Manager::MEDIA,
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'layout_style',
							'operator' => '==',
							'value'    => 'style_1',
						),
					),
				),
				'default'    => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'item', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'We repair your past hurts and issues', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vitae commodo nisl.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();

	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];
		?>
		<?php
		if ( $layout_style == 'style_1' ) :
			$tagline = $settings['tagline'];
			$heading = $settings['heading'];
			$image   = ( $settings['image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image']['id'], 'full' ) : $settings['image']['url'];
			if ( ! empty( $image ) ) {
				$this->add_render_attribute( 'image', 'src', $image );
				$this->add_render_attribute( 'image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image'] ) );
				$this->add_render_attribute( 'image', 'title', \Elementor\Control_Media::get_image_title( $settings['image'] ) );
				$settings['image_size'] = 'full';
				$image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image' );
			}
			?>
<section class="faq-section sec-pad bg-color-4">
			<?php if ( $image ) : ?>
	<figure class="image-layer"><?php echo $image_html; ?></figure>
	<?php endif; ?>
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-xl-6 col-lg-12 col-md-12 content-column">
				<div id="content_block_8">
					<div class="content-box">
						<div class="sec-title">
							<p><?php echo $tagline; ?></p>
							<h2><?php echo $heading; ?></h2>
						</div> <?php else : ?>
						<div class="service-details-content">
							<div class="accordion-inner"> <?php endif; ?>
								<ul class="accordion-box">
									<?php
									$i = 0;
									foreach ( $settings['items'] as $item ) {
										$item_title   = $item['item_title'];
										$item_content = $item['item_content'];
										$i++;

										$class1 = 'active-block';
										$class2 = 'active';
										$class3 = 'current';
										?>
									<li class="accordion block 
										<?php
										if ( $i == 1 ) :
											echo $class1;
										endif;
										?>
			  ">
										<div class="acc-btn 
										<?php
										if ( $i == 1 ) :
											echo $class2;
										endif;
										?>
			">
											<div class="icon-outer"><i class="far fa-angle-up"></i></div>
											<h5><?php echo $item_title; ?></h5>
										</div>
										<div class="acc-content 
										<?php
										if ( $i == 1 ) :
											echo $class3;
										endif;
										?>
														">
											<div class="text">
												<p><?php echo $item_content; ?></p>
											</div>
										</div>
									</li>
										<?php
									}
									?>
								</ul>

								<?php if ( $layout_style == 'style_2' ) : ?>
							</div>
						</div> <?php else : ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
		<?php
	}

	protected function _content_template() {
	}
}
