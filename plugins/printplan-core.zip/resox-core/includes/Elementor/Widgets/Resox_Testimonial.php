<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Testimonial extends Widget_Base {

	public function get_name() {
		return 'resox_testimonial';
	}

	public function get_title() {
		return esc_html__( 'Resox Testimonial', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'testimonial_js' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'general', 'resox' ),
			)
		);
		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),
				),
				'default' => 'style_1',
			)
		);
		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Our Testimonials', 'resox' ),
			)
		);
		$this->add_control(
			'extra_class',
			array(
				'label'       => esc_html__( 'Extra Class', 'resox' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'What Our Patients Say', 'resox' ),
			)
		);
		$this->add_control(
			'background',
			array(
				'label'   => esc_html__( 'Background', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'item', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Name', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Kevin Martin', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'I was very impresed by the power wash resox services lorem ipsum is simply free text available used by copy typing refreshing. Neque porro noting est qui.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];
		$tagline      = $settings['tagline'];
		$heading      = $settings['heading'];
		$extra_class  = $settings['extra_class'];
		$public_title_tag  = $settings['public_title_tag'];
		if ( ! empty( $extra_class ) ) {
			$section_class = $extra_class;
		} else {
			$section_class = '';
		}

		?>
		<?php if ( $layout_style == 'style_1' ) { ?>
<section class="testimonial-section sec-pad centred <?php echo esc_attr( $section_class ); ?>">
	<div class="auto-container">
		<div class="sec-title">
			<p><?php echo $tagline; ?></p>
			<<?php echo $public_title_tag; ?> class="typo-title-text">
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
		</div>
		<div class="inner-container">
			<div class="three-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
				<?php
							$i = 1;
				foreach ( $settings['items'] as $item ) {
					$item_title   = $item['item_title'];
					$item_content = $item['item_content'];
					$item_image   = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
					if ( ! empty( $item_image ) ) {
						$this->add_render_attribute( 'item_image', 'src', $item_image );
						$this->add_render_attribute( 'item_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_image'] ) );
						$this->add_render_attribute( 'item_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_image'] ) );
						$item['item_image_size'] = 'full';
						$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_image' );
					}
					?>
				<div class="testimonial-block-one">
					<div class="inner-box">
						<h4><?php echo $item_title; ?></h4>
						<p><?php echo $item_content; ?></p>
						<figure class="image-box"><?php echo $item_image_html; ?></figure>
						<figure class="quote-box"><img src="<?php echo Resox_CORE_ASSETS; ?>/images/quote-1.png" alt="">
						</figure>
					</div>
				</div>
					<?php
					$i++;
				}
				?>
			</div>
		</div>
	</div>
</section>
			<?php
		} elseif ( $layout_style == 'style_2' ) {
			$background = ( $settings['background']['id'] != '' ) ? wp_get_attachment_image_url( $settings['background']['id'], 'full' ) : $settings['background']['url'];
			?>
<section class="testimonial-style-two" style="background-image: url(<?php echo esc_url( $background ); ?>);">
	<div class="auto-container">
		<div class="single-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
			<?php
						$i = 1;
			foreach ( $settings['items'] as $item ) {
				$item_title   = $item['item_title'];
				$item_content = $item['item_content'];
				$item_image   = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
				if ( ! empty( $item_image ) ) {
					$this->add_render_attribute( 'item_image', 'src', $item_image );
					$this->add_render_attribute( 'item_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_image'] ) );
					$this->add_render_attribute( 'item_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_image'] ) );
					$item['item_image_size'] = 'full';
					$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_image' );
				}
				?>
			<div class="testimonial-content">
				<div class="inner-box">
					<figure class="image-box"><?php echo $item_image_html; ?></figure>
					<div class="text">
						<h2><?php echo $item_content; ?></h2>
						<h3>- <?php echo $item_title; ?></h3>
					</div>
				</div>
			</div>
				<?php
				$i++;
			}
			?>
		</div>
	</div>
</section>
<?php } ?>
		<?php
	}

	protected function _content_template() {    }
}
