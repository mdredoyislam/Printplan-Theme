<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Skin_Base;
use Elementor\Repeater;

class Skin_Classic_Team extends Skin_Base {
	public function __construct( Widget_Base $parent ) {
		$this->parent = $parent;
		$this->_register_controls_actions();
		add_action( 'elementor/element/resox_team/general/before_section_end', array( $this, 'register_controls' ) );
		add_action( 'elementor/element/resox_team/general/after_section_end', array( $this, 'update_controls' ) );
	}
	public function get_id() {
		return 'custom';
	}

	public function get_title() {
		return __( 'Grid', 'ele-custom-skin' );
	}

	protected function _register_controls_actions() {
		parent::_register_controls_actions();
	}

	public function update_controls( Widget_Base $widget ) {
		$this->parent = $widget;
		$this->parent->update_control(
			'tagline',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'custom',
						),
					),
				),
			)
		);
		$this->parent->update_control(
			'heading',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'custom',
						),
					),
				),
			)
        );
        $this->parent->update_control(
			'content',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'custom',
						),
					),
				),
			)
        );
	}

	public function register_controls( Widget_Base $widget ) {

		$this->parent->start_injection(
			array(
				'type' => 'section',
				'at'   => 'end',
				'of'   => 'general',
			)
		);

		$this->add_control(
			'grid_column',
			array(
				'label'   => esc_html__( 'Column', 'resox-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'2' => esc_html__( '2', 'resox-core' ),
					'3' => esc_html__( '3', 'resox-core' ),
					'4' => esc_html__( '4', 'resox-core' ),
				),
				'default' => '3',

			)
		);

		$this->parent->end_injection();

	}

	public function render() {
		$settings    = $this->parent->get_settings_for_display();
		$grid_column = $settings[ $this->get_control_id( 'grid_column' ) ];

		switch ( $grid_column ) {
			case '2':
				$column = 'col-lg-6';
				break;
			case '3':
				$column = 'col-lg-4';
				break;
			default:
				$column = 'col-lg-3';
				break;
		}
		?>

<!-- service-page-section -->
    <section class="team-page-section">
        <div class="auto-container">
            <div class="row clearfix">
            <?php
					$i = 1;
					foreach ($settings['items'] as $item) {
						$item_image = ($item['item_image']['id'] != '') ? wp_get_attachment_image_url($item['item_image']['id'], 'full') : $item['item_image']['url'];
						
						$item_name        = $item['item_name'];
						$item_designation = $item['item_designation'];
                        
                        $item_menu_link     = $item['item_link'];
                        $item_menu_target   = $item['item_link']['is_external'] ? ' target="_blank"' : '';
                        $item_menu_nofollow = $item['item_link']['nofollow'] ? ' rel="nofollow"' : '';
                        
                        
						$item_social_links = $item['item_social_links'];
					?>
                <div class="<?php echo $column; ?> col-md-6 col-sm-12 team-block">
                    <div class="team-block-one">
                        <div class="inner-box">
                            <figure class="image-box">
                            <img src="<?php echo esc_url($item_image);?>" alt="<?php echo esc_attr("team image","resox-core");?>" loading="lazy"/>
                                <ul class="social-links clearfix">
                                    <?php echo $item_social_links; ?>
                                </ul>
                            </figure>
                            <div class="lower-content">
                                <h5><a href="<?php echo esc_url( $item_menu_link['url'] ); ?>" <?php echo $item_menu_target . ' ' . $item_menu_nofollow; ?>><?php echo $item_name; ?></a></h5>
                                <span class="designation"><?php echo $item_designation; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
						$i++;
					}
					?>

            </div>
        </div>
    </section>
<!-- service-page-section end -->
		<?php
	}

}