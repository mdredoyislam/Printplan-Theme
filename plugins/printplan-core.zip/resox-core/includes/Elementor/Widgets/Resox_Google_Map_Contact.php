<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Google_Map_Contact extends Widget_Base {


	public function get_name() {
		return 'contact_google_map_resex';
	}

	public function get_title() {
		return esc_html__( 'Resox Google Map', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);
		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),

				),
				'default' => 'style_1',

			)
		);

		$this->add_control(
			'map_content',
			array(
				'label'       => esc_html__( 'Map Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$this->end_controls_section();
	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$map_content  = $settings['map_content'];
		$layout_style = $settings['layout_style'];

		?> 
		<?php if ( $layout_style == 'style_1' ) { ?>
		<section class="google-map-section style-two">
			<div class="auto-container">
				<div class="map-inner">
						<?php echo $map_content; ?>
				</div>
			</div>
		</section> 
	<?php } elseif ( $layout_style == 'style_2' ) { ?>
		<section class="google-map-section">
				<div class="map-inner">
						<?php echo $map_content; ?>
				</div>
		</section> 
			<?php
	}
	}

	protected function _content_template() {
	}
}
