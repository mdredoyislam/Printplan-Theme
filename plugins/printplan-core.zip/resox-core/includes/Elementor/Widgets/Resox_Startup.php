<?php

namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Startup extends Widget_Base
{











	public function get_name()
	{
		return 'resox_startup';
	}

	public function get_title()
	{
		return esc_html__('Resox Startup', 'resox');
	}

	public function get_icon()
	{
		return 'sds-widget-ico';
	}

	public function get_categories()
	{
		return array('resox');
	}

	protected function _register_controls()
	{

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__('general', 'resox'),
			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__('Tagline', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('We’re here to help you', 'resox'),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__('Heading', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Start Up Your Health Care With Us', 'resox'),
			)
		);

		$this->add_control(
			'icon',
			array(
				'label' => esc_html__('Icon', 'resox'),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'text',
			array(
				'label'   => esc_html__('Mesage Text', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Resox is trust by more <br>then <span>8800</span> healthy patients', 'resox'),
			)
		);

		$this->add_control(
			'form_title',
			array(
				'label'   => esc_html__('Form Title', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Fill the form', 'resox'),
			)
		);

		$this->add_control(
			'form_content',
			array(
				'label'   => esc_html__('Form Content', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Lorem ipsum dolor sit amet, conse ctetur adipisicin elit ipmon sed tempor', 'resox'),
			)
		);

		$this->add_control(
			'form_select',
			array(
				'label'   => esc_html__('Form Select', 'resox'),
				'type'    => Controls_Manager::SELECT,
				'options' => resox_get_contact_form_7_posts(),

			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'  => 'background',
				'label' => esc_html__('Background', 'resox'),
				'types' => array('classic', 'gradient'),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__('item', 'resox'),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__('Title', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('No Charges for Consultation', 'resox'),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__('Content', 'resox'),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __('Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem is simply free text quis bibendum.', 'resox'),
				'placeholder' => esc_html__('Type your description here', 'resox'),

			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__('Link', 'resox'),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__('https://your-link.com', 'resox'),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__('Repeater List', 'resox'),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__('Title #1', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
					array(
						'list_title'   => esc_html__('Title #2', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render()
	{
		$settings     = $this->get_settings_for_display();
		$tagline      = $settings['tagline'];
		$heading      = $settings['heading'];
		$icon         = $settings['icon'];
		$text         = $settings['text'];
		$form_title   = $settings['form_title'];
		$form_content = $settings['form_content'];
		$form_select  = $settings['form_select'];
		$public_title_tag  = $settings['public_title_tag'];
?>
		<section class="startup-section">
			<div class="auto-container">
				<div class="row clearfix">
					<div class="col-lg-6 col-md-12 col-sm-12 content-column">
						<div id="content_block_3">
							<div class="content-box mr-40">
								<div class="sec-title light">
									<p><?php echo $tagline; ?></p>
									<<?php echo $public_title_tag; ?> class="typo-title-text">
										<?php echo $heading; ?>
									</<?php echo $public_title_tag; ?>>
								</div>
								<div class="single-box">
									<?php
									$i = 1;
									foreach ($settings['items'] as $item) {
										$item_title   = $item['item_title'];
										$item_content = $item['item_content'];
										$item_link    = $item['item_link']['url'];
										if (!empty($item_link)) {
											$this->add_render_attribute('item_link' . $i, 'href', $item_link);
											if (!empty($item['item_link']['is_external'])) {
												$this->add_render_attribute('item_link' . $i, 'target', '_blank');
											}

											if (!empty($item['item_link']['nofollow'])) {
												$this->add_render_attribute('item_link' . $i, 'rel', 'nofollow');
											}
										}
									?>
										<div class="inner">
											<div class="icon-box"><i class="fas fa-check"></i></div>
											<h4><a href="<?php echo $item_link; ?>"><?php echo $item_title; ?></a></h4>
											<p><?php echo $item_content; ?></p>
										</div>
									<?php
										$i++;
									}
									?>


								</div>
								<div class="inner-box">
									<div class="icon-box"><?php \Elementor\Icons_Manager::render_icon(($icon), array('aria-hidden' => 'true')); ?></div>
									<h3><?php echo $text; ?></h3>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-12 col-sm-12 form-column">
						<div id="content_block_4">
							<div class="form-inner ml-40">
								<h6><?php echo $form_title; ?></h6>
								<p><?php echo $form_content; ?></p>
								<?php
								if (!empty($form_select)) {
									echo do_shortcode('[contact-form-7 id="' . $form_select . '"]');
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
<?php
	}

	protected function _content_template()
	{
	}
}
