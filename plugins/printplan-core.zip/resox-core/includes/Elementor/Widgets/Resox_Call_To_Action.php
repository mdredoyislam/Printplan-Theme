<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Call_To_Action extends Widget_Base {

	public function get_name() {
		return 'resox_call_to_action';
	}

	public function get_title() {
		return esc_html__( 'Resox Call To Action', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'general', 'resox-core' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => esc_html__( 'Title', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Choose the best physio therapy for youself', 'resox-core' ),
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'   => esc_html__( 'Button Text', 'resox-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Book Appointment', 'resox-core' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$public_title_tag     = $settings['public_title_tag'];

		$title        = $settings['title'];
		$button_title = $settings['button_title'];
		$button_link  = $settings['button_link']['url'];
		if ( ! empty( $button_link ) ) {
			$this->add_render_attribute( 'button_link', 'href', $button_link );
			if ( ! empty( $settings['button_link']['is_external'] ) ) {
				$this->add_render_attribute( 'button_link', 'target', '_blank' );
			}

			if ( ! empty( $settings['button_link']['nofollow'] ) ) {
				$this->add_render_attribute( 'button_link', 'rel', 'nofollow' );
			}
		}
		?>
<section class="cta-section bg-color-2">
	<div class="auto-container">
		<div class="inner-box clearfix">
			<div class="text pull-left">
				<<?php echo $public_title_tag; ?> class="typo-title-text">
				<?php echo $title; ?>
			</<?php echo $public_title_tag; ?>>
			</div>
			<div class="btn-box pull-right">
				<a <?php echo $this->get_render_attribute_string( 'button_link' ); ?>
					class="theme-btn-one"><?php echo $button_title; ?></a>
			</div>
		</div>
	</div>
</section>
		<?php
	}

	protected function _content_template() {
	}
}
