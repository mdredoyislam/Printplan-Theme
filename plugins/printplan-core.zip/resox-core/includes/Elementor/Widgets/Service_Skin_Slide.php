<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Skin_Base;
use Elementor\Repeater;

class Skin_Slider_Service extends Skin_Base {
	public function __construct( Widget_Base $parent ) {
		$this->parent = $parent;
		$this->_register_controls_actions();
		add_action( 'elementor/element/resox_service/item/before_section_end', array( $this, 'register_controls' ) );
		add_action( 'elementor/element/resox_service/item/after_section_end', array( $this, 'update_controls' ) );
	}
	public function get_id() {
		return 'slider';
	}

	public function get_title() {
		return __( 'Slider', 'ele-slider-skin' );
	}
	public function get_script_depends() {
		return array( 'service_js' );
	}

	protected function _register_controls_actions() {
		parent::_register_controls_actions();
	}

	public function update_controls( Widget_Base $widget ) {
		$this->parent = $widget;
		$this->parent->update_control(
			'layout_style',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'slider',
						),
					),
				),
			)
		);
		$this->parent->update_control(
			'tagline',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'slider',
						),
					),
				),
			)
		);
		$this->parent->update_control(
			'heading',
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => '_skin',
							'operator' => '!=',
							'value'    => 'slider',
						),
					),
				),
			)
		);
	}

	public function register_controls( Widget_Base $widget ) {

		$this->parent->start_injection(
			array(
				'type' => 'section',
				'at'   => 'end',
				'of'   => 'general',
			)
		);

		$this->add_control(
			'grid_column',
			array(
				'label'   => esc_html__( 'Column', 'resox-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'2' => esc_html__( '2', 'resox-core' ),
					'3' => esc_html__( '3', 'resox-core' ),
					'4' => esc_html__( '4', 'resox-core' ),
				),
				'default' => '3',

			)
		);

		$this->parent->end_injection();

	}

	public function render() {
		$settings    = $this->parent->get_settings_for_display();
		$grid_column = $settings[ $this->get_control_id( 'grid_column' ) ];

		switch ( $grid_column ) {
			case '2':
				$column = 'col-lg-6';
				break;
			case '3':
				$column = 'col-lg-4';
				break;
			default:
				$column = 'col-lg-3';
				break;
		}
		?>
<section class="service-page-section">
	<div class="auto-container">
		<div class="three-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">

		<?php
			$i = 1;
			foreach ( $settings['items'] as $item ) {
				$item_title       = $item['item_title'];
				$item_content     = $item['item_content'];
				$item_image       = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
				$item_icon        = $item['item_icon'];
				$item_button_text = $item['item_button_text'];
				$item_button_link = $item['item_button_link']['url'];
				?>
			<div class="service-block-one">
				<div class="inner-box">
					<div class="image-box">
						<figure class="image"><a href="<?php echo $item_button_link; ?>"><img
									src="<?php echo $item_image; ?>" loading="lazy" alt="<?php echo esc_attr("team image","resox-core");?>"></a> </figure>
						<div class="icon-box">
							<?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?>
						</div>
					</div>
					<div class="lower-content">
						<h4><a href="<?php echo $item_button_link; ?>"><?php echo $item_title; ?></a></h4>
						<p><?php echo $item_content; ?></p>
						<div class="link"><a href="<?php echo $item_button_link; ?>"><i
									class="fas fa-chevron-circle-right"></i><?php echo $item_button_text; ?></a>
						</div>
					</div>
				</div>
			</div>
			<?php
				$i++;
			}
			?>

		</div>
	</div>
</section>



<!-- service-page-section end -->
		<?php
	}

}
