<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Gallery extends Widget_Base {








	public function get_name() {
		return 'resox_gallery';
	}

	public function get_title() {
		return esc_html__( 'Resox Gallery', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'gallery_js' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox-core' ),
			)
		);

		$this->add_control(
			'slide_on_off',
			array(
				'label'        => esc_html__( 'Slider', 'resox-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'your-plugin' ),
				'label_off'    => __( 'No', 'your-plugin' ),
				'return_value' => true,
				'default'      => false,
			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'item_galley_image',
			array(
				'label'   => esc_html__( 'Galley Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$slide_on_off = $settings['slide_on_off'];
		?>
		<?php if($slide_on_off == 'true'){ ?>
		<section class="gallery-section pt-120">
			<div class="container-fluid">
				<div class="four-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
				<?php
					$i = 1;
					foreach ( $settings['items'] as $item ) {
						$item_galley_image = ( $item['item_galley_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_galley_image']['id'], 'full' ) : $item['item_galley_image']['url'];
						if ( ! empty( $item_galley_image ) ) {
							$this->add_render_attribute( 'item_galley_image', 'src', $item_galley_image );
							$this->add_render_attribute( 'item_galley_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_galley_image'] ) );
							$this->add_render_attribute( 'item_galley_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_galley_image'] ) );
							$item['item_galley_image_size'] = 'full';
							$item_galley_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_galley_image' );
						}
						?>
					<div class="gallery-block-one">
						<div class="inner-box">
							<figure class="image-box"><?php echo $item_galley_image_html; ?></figure>
							<div class="link"><a href="<?php echo esc_url( $item_galley_image ); ?>" class="lightbox-image" data-fancybox="gallery"><i class="flaticon-plus-symbol"></i></a></div>
						</div>
					</div>
					
					<?php
			$i++;
		}
		?>

				</div>
			</div>
		</section>
	<?php } else { ?>
	
		<section class="gallery-section">
			<div class="container-fluid">
				<div class="row clearfix">
		<?php
		$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_galley_image = ( $item['item_galley_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_galley_image']['id'], 'full' ) : $item['item_galley_image']['url'];
			if ( ! empty( $item_galley_image ) ) {
				$this->add_render_attribute( 'item_galley_image', 'src', $item_galley_image );
				$this->add_render_attribute( 'item_galley_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_galley_image'] ) );
				$this->add_render_attribute( 'item_galley_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_galley_image'] ) );
				$item['item_galley_image_size'] = 'full';
				$item_galley_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_galley_image' );
			}
			?>
			<div class="col-lg-3 col-md-6 col-sm-12 gallery-block">
				<div class="gallery-block-one">
					<div class="inner-box">
						<figure class="image-box"><?php echo $item_galley_image_html; ?></figure>
						<div class="link"><a href="<?php echo esc_url( $item_galley_image ); ?>" class="lightbox-image" data-fancybox="gallery"><i class="flaticon-plus-symbol"></i></a></div>
					</div>
				</div>
			</div>
			<?php
			$i++;
		}
		?>
			</div>
		</div>
	</section>

		<?php
		}
	}

	protected function _content_template() {
	}
}
