<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Feature_Two extends Widget_Base {


	public function get_name() {
		return 'resox_feature_two';
	}

	public function get_title() {
		return esc_html__( 'Resox Feature Two', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);
		$this->add_control(
			'extra_class',
			array(
				'label'   => esc_html__( 'Extra Class', 'resox' ),
				'type'    => Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '2 Tips <br>How Can <br>Chiropractic Care Help You', 'resox' ),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Button Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Book Appointment', 'resox' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Body Relexation', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Neque porro quisquam est, qui dolorem ipsum quia dolor.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings    = $this->get_settings_for_display();
		$extra_class     = $settings['extra_class'];
		$section_class  = $extra_class ?? '';
		$heading     = $settings['heading'];
		$public_title_tag     = $settings['public_title_tag'];
		$button_text = $settings['button_text'];
		$button_link = $settings['button_link']['url'];

		?> 
<section class="feature-style-two <?php echo esc_attr($section_class);?>">
  <div class="auto-container">
	<div class="inner-container clearfix">
	  <div class="feature-block-two">
		<div class="inner-box bg-color-2">
		  <div class="content-inner">
			<<?php echo $public_title_tag; ?> class="typo-title-text">
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
			<a href="<?php echo $button_link; ?>" class="theme-btn-one"><?php echo $button_text; ?></a>
		  </div>
		</div>
	  </div>
		<?php
		$i = 0;
		foreach ( $settings['items'] as $item ) {
			$i++;
			$item_title   = $item['item_title'];
			$item_content = $item['item_content'];
			$item_image   = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
			?>
			 <div class="feature-block-two">
				<div class="inner-box centred">
				<div class="image-layer" style="background-image: url(<?php echo $item_image; ?>);"></div>
				<div class="content-box">
					<div class="count-box"><span>0<?php echo $i; ?></span></div>
					<h3><?php echo $item_title; ?></h3>
					<p><?php echo $item_content; ?></p>
				</div>
				</div>
			</div> 
			<?php
		}
		?>
	</div>
  </div>
</section> 
		<?php
	}

	protected function _content_template() {
	}
}
