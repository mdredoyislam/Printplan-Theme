<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Resox\Helper\Elementor\Settings\Header;

class Resox_Our_Certification extends Widget_Base {


	public function get_name() {
		return 'our_certification';
	}

	public function get_title() {
		return esc_html__( 'Our Certification', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'Resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);
		Header::resox_coloumn_control( $this, 6, 2 );

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Certificates & Education', 'resox-core' ),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox-core' ),
			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$heading  = $settings['heading'];
		$content  = $settings['content'];
		$public_title_tag  = $settings['public_title_tag'];
		$class    = Header::resox_coloumn( $this, $settings );
		?> 
		<section class="certificates-section bg-color-4">
			<div class="auto-container">
				<div class="row clearfix">
					<div class="col-lg-4 col-md-12 col-sm-12 text-column">
						<div class="text">
						<<?php echo $public_title_tag; ?> class="typo-title-text">
							<?php echo $heading; ?>
						</<?php echo $public_title_tag; ?>>
						<p><?php echo $content; ?></p>
						</div>
					</div>
					<div class="col-lg-8 col-md-12 col-sm-12 certificates-column">
						<div class="certificates-inner ml-50">
							<div class="row clearfix">
								<?php
								$i = 1;
								foreach ( $settings['items'] as $item ) {
									$item_image = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
									if ( ! empty( $item_image ) ) {
										$this->add_render_attribute( 'item_image', 'src', $item_image );
										$this->add_render_attribute( 'item_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_image'] ) );
										$this->add_render_attribute( 'item_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_image'] ) );
										$item['item_image_size'] = 'full';
										$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_image' );
									}
									?>
								 <div class="<?php echo esc_attr( $class ); ?> col-md-6 col-sm-12 image-column">
										<figure class="image-box"><?php echo $item_image_html; ?></figure>
									</div> 
									<?php
									$i++;
								}
								?>


							</div>
						</div>
					</div>
				</div>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
