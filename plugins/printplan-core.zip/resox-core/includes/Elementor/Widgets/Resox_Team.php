<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

require 'Skin_Team_Page.php';

class Resox_Team extends Widget_Base
{






	public function get_name()
	{
		return 'resox_team';
	}

	public function get_title()
	{
		return esc_html__('Resox Team', 'resox');
	}

	public function get_icon()
	{
		return 'sds-widget-ico';
	}

	public function get_categories()
	{
		return array('resox');
	}
	protected function _register_skins() {
		$this->add_skin( new Skin_Classic_Team( $this ) );
	}

	protected function _register_controls()
	{

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__('General', 'resox'),
			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__('Tagline', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Professional team', 'resox'),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__('Heading', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Meet Our Therapists', 'resox'),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__('Content', 'resox'),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __('There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.', 'resox'),
				'placeholder' => esc_html__('Type your description here', 'resox'),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__('ITEM', 'resox'),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__('Image', 'resox'),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$repeater->add_control(
			'item_name',
			array(
				'label'   => esc_html__('Name', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Jessica Brown', 'resox'),
			)
		);

		$repeater->add_control(
			'item_designation',
			array(
				'label'   => esc_html__('Designation', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Therapist', 'resox'),
			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__('Link', 'resox'),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__('https://your-link.com', 'resox'),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$repeater->add_control(
			'item_social_links',
			array(
				'label'       => esc_html__('Social Links', 'resox'),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __('', 'resox'),
				'placeholder' => esc_html__('Type your description here', 'resox'),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__('Repeater List', 'resox'),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__('Title #1', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
					array(
						'list_title'   => esc_html__('Title #2', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );
	}
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$tagline  = $settings['tagline'];
		$heading  = $settings['heading'];
		$content  = $settings['content'];
		$public_title_tag  = $settings['public_title_tag'];
?> 
		<section class="team-section">
			<div class="auto-container">
				<div class="title-inner clearfix">
					<div class="sec-title pull-left">
						<p><?php echo $tagline; ?></p>
						<<?php echo $public_title_tag; ?> class="typo-title-text">
							<?php echo $heading; ?>
						</<?php echo $public_title_tag; ?>>
					</div>
					<div class="text pull-right">
						<p><?php echo $content; ?></p>
					</div>
				</div>
				<div class="team-inner clearfix">
					<?php
					$i = 1;
					foreach ($settings['items'] as $item) {
						$item_image = ($item['item_image']['id'] != '') ? wp_get_attachment_image_url($item['item_image']['id'], 'full') : $item['item_image']['url'];
						if (!empty($item_image)) {
							$this->add_render_attribute('item_image', 'src', $item_image);
							$this->add_render_attribute('item_image', 'alt', \Elementor\Control_Media::get_image_alt($item['item_image']));
							$this->add_render_attribute('item_image', 'title', \Elementor\Control_Media::get_image_title($item['item_image']));
							$item['item_image_size'] = 'full';
							$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html($item, 'item_image');
						}
						$item_name        = $item['item_name'];
						$item_designation = $item['item_designation'];
						$item_link        = $item['item_link']['url'];
						if (!empty($item_link)) {
							$this->add_render_attribute('item_link' . $i, 'href', $item_link);
							if (!empty($item['item_link']['is_external'])) {
								$this->add_render_attribute('item_link' . $i, 'target', '_blank');
							}

							if (!empty($item['item_link']['nofollow'])) {
								$this->add_render_attribute('item_link' . $i, 'rel', 'nofollow');
							}
						}
						$item_social_links = $item['item_social_links'];
					?>
						<div class="team-block-one">
							<div class="inner-box">
								<figure class="image-box">
									<?php echo $item_image_html; ?>
									<ul class="social-links clearfix">
										<?php echo $item_social_links; ?>
									</ul>
								</figure>
								<div class="lower-content">
									<h5><a href="<?php echo $item_link; ?>"><?php echo $item_name; ?></a></h5>
									<span class="designation"><?php echo $item_designation; ?></span>
								</div>
							</div>
						</div>
					<?php
						$i++;
					}
					?>


				</div>
			</div>
		</section>
<?php
	}

	protected function _content_template()
	{
	}
}
