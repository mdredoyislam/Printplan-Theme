<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

require 'Service_Single_Skin_One.php';
require 'Service_Single_Skin_Two.php';
class Resox_Service_Single extends Widget_Base {

	public function get_name() {
		return 'resox_service_single';
	}

	public function get_title() {
		return esc_html__( 'Resox Service Single', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_skins() {
		$this->add_skin( new Skin_Single_One( $this ) );
		$this->add_skin( new Skin_Single_Two( $this ) );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);

		$this->add_control(
			'bg_img',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'icon',
			array(
				'label' => esc_html__( 'Icon', 'resox' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'What We’re Offering', 'resox' ),
			)
		);
		$this->add_control(
			'content',
			array(
				'label'   => esc_html__( 'Content', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'resox' ),
			)
		);
		$repeater = new Repeater();

		$repeater->add_control(
			'item_content',
			array(
				'label'   => esc_html__( 'Content', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Lorem Ipsum is simply dummy text of the new design printng and type setting Ipsum take a look at our round. When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.', 'resox' ),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'item_content' => esc_html__( 'Refresing to get a personal touch.', 'resox' ),
					),
					array(
						'item_content' => esc_html__( 'Velit esse cillum eu fugiat pariatur.', 'resox' ),
					),
					array(
						'item_content' => esc_html__( 'Duis aute irure dolor in in voluptate.', 'resox' ),
					),
					array(
						'item_content' => esc_html__( 'Duis aute irure dolor in in voluptate.', 'resox' ),
					),
				),
			)
		);
		$this->add_control(
			'content_two',
			array(
				'label'   => esc_html__( 'Content Two', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Donor Ipsum Lorem', 'resox' ),
			)
		);
		$this->add_control(
			'highlight_label',
			array(
				'label'   => esc_html__( 'Highlighted Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Lorem Ipsum is simply dummy', 'resox' ),
			)
		);

		$this->end_controls_section();

		resox_public_header_control( $this, 'h4' );

		resox_public_content_control( $this );

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$icon     = $settings['icon'];
		// From Public Header
		$public_title_tag = $settings['public_title_tag'];

		$heading = $settings['heading'];
		$this->add_render_attribute( 'heading', 'class', 'typo-title-text' );
		$this->add_inline_editing_attributes( 'heading', 'none' );

		$content = $settings['content'];
		$this->add_render_attribute( 'content', 'class', 'typo-content-text' );
		$this->add_inline_editing_attributes( 'content', 'none' );
		// From Public Header

		$content_two = $settings['content_two'];
		$bg_img      = ( $settings['bg_img']['id'] != '' ) ? wp_get_attachment_image_url( $settings['bg_img']['id'], 'full' ) : $settings['bg_img']['url'];
		if ( ! empty( $bg_img ) ) {
			$this->add_render_attribute( 'bg_img', 'src', $bg_img );
			$this->add_render_attribute( 'bg_img', 'alt', \Elementor\Control_Media::get_image_alt( $settings['bg_img'] ) );
			$this->add_render_attribute( 'bg_img', 'title', \Elementor\Control_Media::get_image_title( $settings['bg_img'] ) );
			$settings['bg_img_size'] = 'full';
			$bg_img_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'bg_img' );

		}

		?>
<div class="service-details-content">
	<div class="content-one">
		<?php if ( $bg_img ) : ?>
		<figure class="image-box">
			<?php echo $bg_img_html; ?>
			<?php \Elementor\Icons_Manager::render_icon( ( $icon ), array( 'aria-hidden' => 'true' ) ); ?>
		</figure>
		<?php endif; ?>
		<div class="text">
			<!-- Title -->
			<<?php echo $public_title_tag; ?> <?php echo $this->get_render_attribute_string( 'heading' ); ?>>
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
			<!-- Title -->

			<!-- content -->
			<p <?php echo $this->get_render_attribute_string( 'content' ); ?>><?php echo $content; ?></p>
			<p <?php echo $this->get_render_attribute_string( 'content' ); ?>><?php echo $content_two; ?></p>
			<!-- content -->


		</div>
	</div>
</div>
		<?php
	}

	protected function _content_template() {
	}
}
