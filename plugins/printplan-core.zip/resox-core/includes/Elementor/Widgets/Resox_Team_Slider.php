<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;



class Resox_Team_Slider extends Widget_Base
{

	public function get_name()
	{
		return 'resox_team_slider';
	}

	public function get_title()
	{
		return esc_html__('Resox Team Slider', 'resox');
	}

	public function get_icon()
	{
		return 'sds-widget-ico';
	}

	public function get_categories()
	{
		return array('resox');
	}
	public function get_script_depends() {
		return array( 'team_js' );
	}

	protected function _register_controls()
	{
		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__('ITEM', 'resox'),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__('Image', 'resox'),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$repeater->add_control(
			'item_name',
			array(
				'label'   => esc_html__('Name', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Jessica Brown', 'resox'),
			)
		);

		$repeater->add_control(
			'item_designation',
			array(
				'label'   => esc_html__('Designation', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Therapist', 'resox'),
			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__('Link', 'resox'),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__('https://your-link.com', 'resox'),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$repeater->add_control(
			'item_social_links',
			array(
				'label'       => esc_html__('Social Links', 'resox'),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __('', 'resox'),
				'placeholder' => esc_html__('Type your description here', 'resox'),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__('Repeater List', 'resox'),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__('Title #1', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
					array(
						'list_title'   => esc_html__('Title #2', 'resox'),
						'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'resox'),
					),
				),
			)
		);

		$this->end_controls_section();
	}
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		
?> 
		<section class="team-section sec-pad">
            <div class="auto-container">
                <div class="four-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
				<?php
					$i = 1;
					foreach ($settings['items'] as $item) {
						$item_image = ($item['item_image']['id'] != '') ? wp_get_attachment_image_url($item['item_image']['id'], 'full') : $item['item_image']['url'];
						if (!empty($item_image)) {
							$this->add_render_attribute('item_image', 'src', $item_image);
							$this->add_render_attribute('item_image', 'alt', \Elementor\Control_Media::get_image_alt($item['item_image']));
							$this->add_render_attribute('item_image', 'title', \Elementor\Control_Media::get_image_title($item['item_image']));
							$item['item_image_size'] = 'full';
							$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html($item, 'item_image');
						}
						$item_name        = $item['item_name'];
						$item_designation = $item['item_designation'];
						$item_link        = $item['item_link']['url'];
						if (!empty($item_link)) {
							$this->add_render_attribute('item_link' . $i, 'href', $item_link);
							if (!empty($item['item_link']['is_external'])) {
								$this->add_render_attribute('item_link' . $i, 'target', '_blank');
							}

							if (!empty($item['item_link']['nofollow'])) {
								$this->add_render_attribute('item_link' . $i, 'rel', 'nofollow');
							}
						}
						$item_social_links = $item['item_social_links'];
					?>
                    <div class="team-block-one">
						<div class="inner-box">
							<figure class="image-box">
								<?php echo $item_image_html; ?>
								<ul class="social-links clearfix">
									<?php echo $item_social_links; ?>
								</ul>
							</figure>
							<div class="lower-content">
								<h5><a href="<?php echo $item_link; ?>"><?php echo $item_name; ?></a></h5>
								<span class="designation"><?php echo $item_designation; ?></span>
							</div>
						</div>
					</div>
					<?php
						$i++;
					}
					?>
					
                </div>
            </div>
        </section>
<?php
	}

	protected function _content_template()
	{
	}
}