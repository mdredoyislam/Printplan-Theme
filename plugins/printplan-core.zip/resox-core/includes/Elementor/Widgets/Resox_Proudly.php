<?php
namespace Resox\Helper\Elementor\Widgets;

					use Elementor\Utils;
					use Elementor\Controls_Manager;
					use Elementor\Widget_Base;
					use Elementor\Plugin;
					use \Elementor\Repeater;

class Resox_Proudly extends Widget_Base {









	public function get_name() {
		return 'resox_proudly';
	}

	public function get_title() {
		return esc_html__( 'Resox Proudly', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);
		$this->add_control(
			'background_shape',
			array(
				'label'   => 'Background Shape',
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);
		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Solutions to your pain', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'We Proudly Give Quality Treatments', 'resox' ),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Donec pellentesque dapibus interdum. Mauris et tellus congue , rutrum neque a, varius felis. Phasellus nibh diam, tincidunt nec risus ut, auctor gravida metus that covers the front of the eye.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'content_list',
			array(
				'label'       => esc_html__( 'Content List', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Skiled Therapist', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_number',
			array(
				'label'   => esc_html__( 'Number', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '78', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings         = $this->get_settings_for_display();
		$background_shape = ( $settings['background_shape']['id'] != '' ) ? wp_get_attachment_image_url( $settings['background_shape']['id'], 'full' ) : $settings['background_shape']['url'];
		$image            = ( $settings['image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image']['id'], 'full' ) : $settings['image']['url'];
		if ( ! empty( $image ) ) {
			$this->add_render_attribute( 'image', 'src', $image );
			$this->add_render_attribute( 'image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image'] ) );
			$this->add_render_attribute( 'image', 'title', \Elementor\Control_Media::get_image_title( $settings['image'] ) );
			$settings['image_size'] = 'full';
			$image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image' );

		}
							$tagline      = $settings['tagline'];
							$heading      = $settings['heading'];
							$content      = $settings['content'];
							$content_list = $settings['content_list'];
							$public_title_tag = $settings['public_title_tag'];
		?> <!-- proudly-section -->
<section class="proudly-section bg-color-1">
	<div class="pattern-layer" style="background-image: url(<?php echo $background_shape; ?>);"></div>
	<figure class="image-layer"><?php echo $image_html; ?></figure>
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-xl-7 col-lg-12 col-md-12 offset-xl-5 content-column">
				<div id="content_block_2">
					<div class="content-box">
						<div class="sec-title light">
							<p><?php echo $tagline; ?></p>
							<<?php echo $public_title_tag; ?> class="typo-title-text">
								<?php echo $heading; ?>
							</<?php echo $public_title_tag; ?>>
						</div>
						<div class="text">
							<p><?php echo $content; ?></p>
						</div>
		<?php echo $content_list; ?>
						<div class="counter-inner clearfix">
		<?php
								$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_title  = $item['item_title'];
			$item_number = $item['item_number'];
			$item_icon   = $item['item_icon'];
			?>
							 <div class="counter-block">
  <div class="inner-box">
	<div class="icon-box"><?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?></div>
	<div class="count-outer count-box">
	  <span class="count-text" data-speed="1500" data-stop="<?php echo $item_number; ?>">0</span>
	</div>
	<p><?php echo $item_title; ?></p>
  </div>
</div> 
			<?php
			$i++;
		}
		?>
						 
									
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> 
		<?php
	}

	protected function _content_template() {
	}
}
