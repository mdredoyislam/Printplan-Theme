<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Elementor\Core\Schemes;
use Resox\Helper\Elementor\Settings\Header;


class Resox_Blog extends Widget_Base {






	public function get_name() {
		return 'resox_blog';
	}

	public function get_title() {
		return esc_html__( 'Resox Blog', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'service_js' );
	}
	private function get_blog_categories() {
		$options  = array();
		$taxonomy = 'category';
		if ( ! empty( $taxonomy ) ) {
			$terms = get_terms(
				array(
					'parent'     => 0,
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
			if ( ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( isset( $term ) ) {
						$options[''] = 'Select';
						if ( isset( $term->slug ) && isset( $term->name ) ) {
							$options[ $term->slug ] = $term->name;
						}
					}
				}
			}
		}
		return $options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);

		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),

				),
				'default' => 'style_1',

			)
		);
		Header::resox_coloumn_control( $this, 6, 2 );
		$this->add_control(
			'title',
			array(
				'label'       => esc_html__( 'Title', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'News & Article', 'resox-core' ),

			)
		);
		$this->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'Html Tag', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'h1'   => esc_html__( 'H1', 'resox-core' ),
					'h2'   => esc_html__( 'H2', 'resox-core' ),
					'h3'   => esc_html__( 'H3', 'resox-core' ),
					'h4'   => esc_html__( 'H4', 'resox-core' ),
					'h5'   => esc_html__( 'H5', 'resox-core' ),
					'h6'   => esc_html__( 'H6', 'resox-core' ),
					'div'  => esc_html__( 'div', 'resox-core' ),
					'span' => esc_html__( 'span', 'resox-core' ),
					'p'    => esc_html__( 'p', 'resox-core' ),
				),
				'default' => 'h2',

			)
		);

		$this->add_control(
			'content',
			array(
				'label' => esc_html__( 'Tag Line', 'resox-core' ),
				'type'  => Controls_Manager::TEXTAREA,

			)
		);

		$this->add_control(
			'category_id',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Category', 'resox-core' ),
				'options'     => $this->get_blog_categories(),
				'multiple'    => true,
				'label_block' => true,
			)
		);

		$this->add_control(
			'posts_per_page',
			array(
				'label'   => esc_html__( 'Number of Post', 'resox-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
			)
		);

		$this->add_control(
			'order_by',
			array(
				'label'   => esc_html__( 'Order By', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'          => esc_html__( 'Date', 'resox-core' ),
					'ID'            => esc_html__( 'ID', 'resox-core' ),
					'author'        => esc_html__( 'Author', 'resox-core' ),
					'title'         => esc_html__( 'Title', 'resox-core' ),
					'modified'      => esc_html__( 'Modified', 'resox-core' ),
					'rand'          => esc_html__( 'Random', 'resox-core' ),
					'comment_count' => esc_html__( 'Comment count', 'resox-core' ),
					'menu_order'    => esc_html__( 'Menu order', 'resox-core' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'   => esc_html__( 'Order', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => array(
					'desc' => esc_html__( 'DESC', 'resox-core' ),
					'asc'  => esc_html__( 'ASC', 'resox-core' ),
				),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'text_style_section',
			array(
				'label' => __( 'Text Style', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'resox-core' ),
				'scheme'   => Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .blog_heading',
			)
		);
		$this->end_controls_section();
	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];

		$title    = $settings['title'];
		$html_tag = $settings['html_tag'];
		$content  = $settings['content'];

		if ( $settings['category_id'] ) {
			$category_arr = implode( ', ', $settings['category_id'] );
		} else {
			$category_arr = array();
		}

		$posts_per_page = $settings['posts_per_page'];
		$order_by       = $settings['order_by'];
		$order          = $settings['order'];
		$pg_num         = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		$args           = array(
			'post_type'      => array( 'post' ),
			'post_status'    => array( 'publish' ),
			'nopaging'       => false,
			'paged'          => $pg_num,
			'posts_per_page' => $posts_per_page,
			'category_name'  => $category_arr,
			'orderby'        => $order_by,
			'order'          => $order,
		);
		$query          = new \WP_Query( $args );
		$class          = Header::resox_coloumn( $this, $settings );

		?>
		<?php if($layout_style == 'style_1') { ?>
			<section class="news-section sec-pad">
				<div class="auto-container">
					<div class="sec-title centred">
						<p><?php echo $content; ?></p>
						<<?php echo $html_tag; ?> class="blog_heading"><?php echo $title; ?></<?php echo $html_tag; ?>>
					</div>
					<div class="row clearfix">
		<?php
		$i = 0;
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$i++;
				$query->the_post();
				global $post;
				$tags             = wp_get_post_categories( get_the_ID() );

				?>
			<div class="<?php echo $class; ?> col-md-6 col-sm-12 news-block">
				<div class="news-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
					<div class="inner-box">
						<figure class="image-box">
							<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail( 'resox-blog-home' ); ?></a>
							<span class="post-date"><?php echo get_the_date( 'd,M,Y' ); ?></span>
						</figure>
						<div class="lower-content">
							<ul class="post-info clearfix">
								<li><i class="far fa-user-circle"></i>
								<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php esc_html_e( 'By', 'resox-core' ); ?> <?php echo get_the_author(); ?></a>
							</li>
								<li><i class="far fa-comments"></i><?php resox_comments_count(); ?></li>
							</ul>
							<h3><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
							<p><?php echo substr( get_the_excerpt(), 0, 100 ); ?></p>
							<div class="link"><a href="<?php echo esc_url( get_permalink() ); ?>"><i class="fas fa-chevron-circle-right"></i><?php esc_html_e( 'Read More', 'resox' ); ?></a></div>
						</div>
					</div>
				</div>
			</div>
				<?php
			}
			wp_reset_postdata();
		}
		?>

					</div>
				</div>
			</section>
	<?php } elseif($layout_style == 'style_2') { ?>
			<section class="news-section sec-pad">
				<div class="auto-container">
					<div class="three-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
					<?php
						$i = 0;
						if ( $query->have_posts() ) {
							while ( $query->have_posts() ) {
								$i++;
								$query->the_post();
								global $post;
								$tags             = wp_get_post_categories( get_the_ID() );

								?>

						<div class="news-block-one">
							<div class="inner-box">
								<figure class="image-box">
									<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail( 'resox-blog-home' ); ?></a>
									<span class="post-date"><?php echo get_the_date( 'd,M,Y' ); ?></span>
								</figure>
								<div class="lower-content">
									<ul class="post-info clearfix">
										<li><i class="far fa-user-circle"></i>
										<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php esc_html_e( 'By', 'resox-core' ); ?> <?php echo get_the_author(); ?></a>
									</li>
										<li><i class="far fa-comments"></i><?php resox_comments_count(); ?></li>
									</ul>
									<h3><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
									<p><?php echo substr( get_the_excerpt(), 0, 100 ); ?></p>
									<div class="link"><a href="<?php echo esc_url( get_permalink() ); ?>"><i class="fas fa-chevron-circle-right"></i><?php esc_html_e( 'Read More', 'resox' ); ?></a></div>
								</div>
							</div>
						</div>
						
						<?php
				}
				wp_reset_postdata();
			}
			?>
					</div>
				</div>
			</section>
		
		<?php
		}
	}

	protected function _content_template() {
	}
}
