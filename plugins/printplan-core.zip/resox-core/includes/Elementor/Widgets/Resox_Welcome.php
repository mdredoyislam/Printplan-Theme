<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Welcome extends Widget_Base {






	public function get_name() {
		return 'resox_welcome';
	}

	public function get_title() {
		return esc_html__( 'Resox Welcome', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Welcome to clinic', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( "We're a Recognized & Quality Leader in Physiotherapy", 'resox' ),
			)
		);

		$this->add_control(
			'background_shape',
			array(
				'label'   => esc_html__( 'Background Shape', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem is simply free text quis bibendum.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title // 1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings         = $this->get_settings_for_display();
		$tagline          = $settings['tagline'];
		$heading          = $settings['heading'];
		$public_title_tag          = $settings['public_title_tag'];
		$background_shape = ( $settings['background_shape']['id'] != '' ) ? wp_get_attachment_image_url( $settings['background_shape']['id'], 'full' ) : $settings['background_shape']['url'];

		?> 
<section class="welcome-section bg-color-2">
	<div class="pattern-layer" style="background-image: url(<?php echo esc_url( $background_shape ); ?>);"></div>
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-lg-6 col-md-12 col-sm-12 title-column">
				<div class="sec-title light mr-50">
					<p><?php echo $tagline; ?></p>
					<<?php echo $public_title_tag; ?> class="typo-title-text">
						<?php echo $heading; ?>
					</<?php echo $public_title_tag; ?>>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 content-column">
				<div id="content_block_3">
					<div class="content-box">
						<div class="single-box">
		<?php
		$i = 1;
		foreach ( $settings['items'] as $item ) {
			$item_title   = $item['item_title'];
			$item_content = $item['item_content'];
			?>
							<div class="inner">
								<div class="icon-box"><i class="fas fa-check"></i></div>
								<p><?php echo $item_content; ?></p>
							</div> 
			<?php
			$i++;
		}
		?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> 
		<?php
	}

	protected function _content_template() {
	}
}
