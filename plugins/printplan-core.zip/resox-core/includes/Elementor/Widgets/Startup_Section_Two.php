<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Resox\Helper\Elementor\Settings\Header;

class Startup_Section_Two extends Widget_Base {


	public function get_name() {
		return 'startup_section_two';
	}

	public function get_title() {
		return esc_html__( 'Startup Section Two', 'resox-core' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox-core' ),
			)
		);
		Header::resox_coloumn_control( $this, 6, 2 );

		$this->add_control(
			'background_image',
			array(
				'label'   => esc_html__( 'Background Image', 'resox-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'Item', 'resox-core' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '', 'resox-core' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox-core' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox-core' ),

			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__( 'Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox-core' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();
	}
	protected function render() {
		$settings         = $this->get_settings_for_display();
		$background_image = ( $settings['background_image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['background_image']['id'], 'full' ) : $settings['background_image']['url'];
		$class            = Header::resox_coloumn( $this, $settings );

		?> 
		<section class="startup-section alternat-2" style="background-image: url(<?php echo esc_url( $background_image ); ?>);">
			<div class="auto-container">
				<div id="content_block_3">
					<div class="content-box">
						<div class="single-box">
							<div class="row clearfix">
								<?php
								$i = 1;
								foreach ( $settings['items'] as $item ) {
									$item_title   = $item['item_title'];
									$item_content = $item['item_content'];

									$item_menu_link     = $item['item_link'];
									$item_menu_target   = $item['item_link']['is_external'] ? ' target="_blank"' : '';
									$item_menu_nofollow = $item['item_link']['nofollow'] ? ' rel="nofollow"' : '';

									?>
								 
									<div class="<?php echo $class; ?> col-md-6 col-sm-12 single-column">
										<div class="inner mr-20">
											<div class="icon-box"><i class="fas fa-check"></i></div>
											<h4><a href="<?php echo esc_url( $item_menu_link['url'] ); ?>" <?php echo $item_menu_target . ' ' . $item_menu_nofollow; ?>><?php echo $item_title; ?></a></h4>
											<p><?php echo $item_content; ?></p>
										</div>
									</div> 
									<?php
									$i++;
								}
								?>


							</div>
						</div>
					</div>
				</div>
			</div>
		</section> 
		<?php
	}

	protected function _content_template() {
	}
}
