<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_About_Two extends Widget_Base {







	public function get_name() {
		return 'resox_about_two';
	}

	public function get_title() {
		return esc_html__( 'Resox About Two', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'general', 'resox' ),
			)
		);

		$this->add_control(
			'image_01',
			array(
				'label'   => esc_html__( 'Image 01', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'image_02',
			array(
				'label'   => esc_html__( 'Image 02', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'icon_image',
			array(
				'label'   => esc_html__( 'Icon Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'ABOUT CLINIC', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'We’re Offering Whole Range of Treatments For You', 'resox' ),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'There are many variations of passages of available but the majority have suffered alteration in some form, by injected humou or words even slightly believable.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Button Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Discover More', 'resox' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'phone_number_title',
			array(
				'label'   => esc_html__( 'Phone Number Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Call Us Anytime', 'resox' ),
			)
		);

		$this->add_control(
			'phone_number',
			array(
				'label'   => esc_html__( 'Phone Number', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '<a href="tel:6660009999">666 000 9999</a>', 'resox' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'item', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_item_title',
			array(
				'label'   => esc_html__( 'Item Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Magnis Dis Montes Nascet', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_item_content',
			array(
				'label'   => esc_html__( 'Item Content', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Lorem ipsum is simply free dolor sit amet, consecte notted', 'resox' ),
			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$public_title_tag     = $settings['public_title_tag'];

		$image_01 = ( $settings['image_01']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image_01']['id'], 'full' ) : $settings['image_01']['url'];
		if ( ! empty( $image_01 ) ) {
			$this->add_render_attribute( 'image_01', 'src', $image_01 );
			$this->add_render_attribute( 'image_01', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image_01'] ) );
			$this->add_render_attribute( 'image_01', 'title', \Elementor\Control_Media::get_image_title( $settings['image_01'] ) );
			$settings['image_01_size'] = 'full';
			$image_01_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_01' );

		}
							$image_02 = ( $settings['image_02']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image_02']['id'], 'full' ) : $settings['image_02']['url'];
		if ( ! empty( $image_02 ) ) {
			$this->add_render_attribute( 'image_02', 'src', $image_02 );
			$this->add_render_attribute( 'image_02', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image_02'] ) );
			$this->add_render_attribute( 'image_02', 'title', \Elementor\Control_Media::get_image_title( $settings['image_02'] ) );
			$settings['image_02_size'] = 'full';
			$image_02_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image_02' );

		}
							$icon_image = ( $settings['icon_image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['icon_image']['id'], 'full' ) : $settings['icon_image']['url'];
		if ( ! empty( $icon_image ) ) {
			$this->add_render_attribute( 'icon_image', 'src', $icon_image );
			$this->add_render_attribute( 'icon_image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['icon_image'] ) );
			$this->add_render_attribute( 'icon_image', 'title', \Elementor\Control_Media::get_image_title( $settings['icon_image'] ) );
			$settings['icon_image_size'] = 'full';
			$icon_image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_image' );

		}
		$tagline     = $settings['tagline'];
		$heading     = $settings['heading'];
		$content     = $settings['content'];
		$button_text = $settings['button_text'];
		$button_link = $settings['button_link']['url'];
		if ( ! empty( $button_link ) ) {
			$this->add_render_attribute( 'button_link', 'href', $button_link );
			if ( ! empty( $settings['button_link']['is_external'] ) ) {
				$this->add_render_attribute( 'button_link', 'target', '_blank' );
			}

			if ( ! empty( $settings['button_link']['nofollow'] ) ) {
				$this->add_render_attribute( 'button_link', 'rel', 'nofollow' );
			}
		}
		$phone_number_title = $settings['phone_number_title'];
		$phone_number       = $settings['phone_number'];
		?> <section class="about-style-two">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="col-lg-6 col-md-12 col-sm-12 image-column">
				<div id="image_block_1">
					<div class="image-box mr-30">
						<figure class="image image-1"><?php echo $image_01_html; ?></figure>
						<figure class="image image-2"><?php echo $image_02_html; ?></figure>
						<figure class="icon-box rotate-me"><?php echo $icon_image_html; ?></figure>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 content-column">
				<div id="content_block_7">
					<div class="content-box ml-40">
						<div class="sec-title">
							<p><?php echo $tagline; ?></p>
							<<?php echo $public_title_tag; ?> class="typo-title-text">
								<?php echo $heading; ?>
							</<?php echo $public_title_tag; ?>>
						</div>
						<div class="text">
							<p><?php echo $content; ?></p>
						</div>
						<div class="inner-box">
							<?php
								$i = 1;
							foreach ( $settings['items'] as $item ) {
								$item_item_title   = $item['item_item_title'];
								$item_item_content = $item['item_item_content'];
								?>
							<div class="single-item">
								<h5><?php echo $item_item_title; ?></h5>
								<p><?php echo $item_item_content; ?></p>
							</div>
								<?php
								$i++;
							}
							?>


						</div>
						<div class="lower-box clearfix">
							<div class="btn-box pull-left mr-10"><a
									<?php echo $this->get_render_attribute_string( 'button_link' ); ?>
									class="theme-btn-one"><?php echo $button_text; ?></a></div>
							<div class="support-box pull-left">
								<i class="flaticon-telephone"></i>
								<p><?php echo $phone_number_title; ?></p>
								<h3><?php echo $phone_number; ?></h3>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		<?php
	}

	protected function _content_template() {
	}
}
