<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

class Resox_Footer extends Widget_Base {

	public function get_name() {
		return 'resox_footer';
	}

	public function get_title() {
		return esc_html__( 'Resox Footer', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);

		$this->add_control(
			'footer_bottom_on_off',
			array(
				'label'        => esc_html__( 'Footer Bottom', 'resox-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'your-plugin' ),
				'label_off'    => __( 'No', 'your-plugin' ),
				'return_value' => '1',
				'default'      => false,
			)
		);

		$this->add_control(
			'logo_img',
			array(
				'label'   => esc_html__( 'Logo', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'content',
			array(
				'label'   => esc_html__( 'Content', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'There are many variatio of lorem ipsum available.', 'resox' ),
			)
		);

		$this->add_control(
			'contact_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox-core' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'contact_label',
			array(
				'label'   => esc_html__( 'Label', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Call us anytime', 'resox' ),
			)
		);

		$this->add_control(
			'contact_number',
			array(
				'label'       => esc_html__( 'Contact Number', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '666 000 9999', 'resox-core' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox-core' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$repeater->add_control(
			'item_name',
			array(
				'label'       => esc_html__( 'Name', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discover More', 'resox-core' ),
			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'         => esc_html__( 'Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Item List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'item_name' => esc_html__( 'needhelp@info.com', 'resox-core' ),
						'item_link' => esc_html__( 'mailto:needhelp@info.com', 'resox-core' ),
					),
					array(
						'item_name' => esc_html__( '88 broklyn silver street, USA', 'resox-core' ),
						'item_link' => esc_html__( '', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'links',
			array(
				'label' => esc_html__( 'Links', 'resox' ),
			)
		);

		$this->add_control(
			'links_on_off',
			array(
				'label'        => esc_html__( 'Enable', 'resox-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'your-plugin' ),
				'label_off'    => __( 'No', 'your-plugin' ),
				'return_value' => '1',
				'default'      => false,
			)
		);

		$this->add_control(
			'links_heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Links', 'resox' ),
			)
		);

		$this->add_control(
			'links_menu',
			array(
				'label'   => esc_html__( 'Select Menu', 'resox' ),
				'type'    => Controls_Manager::SELECT,
				'options' => resox_get_menu_list(),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services',
			array(
				'label' => esc_html__( 'Services', 'resox' ),
			)
		);

		$this->add_control(
			'services_on_off',
			array(
				'label'        => esc_html__( 'Enable', 'resox-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'your-plugin' ),
				'label_off'    => __( 'No', 'your-plugin' ),
				'return_value' => '1',
				'default'      => false,
			)
		);

		$this->add_control(
			'services_heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Services', 'resox' ),
			)
		);

		$this->add_control(
			'services_menu',
			array(
				'label'   => esc_html__( 'Select Menu', 'resox' ),
				'type'    => Controls_Manager::SELECT,
				'options' => resox_get_menu_list(),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'appointment',
			array(
				'label' => esc_html__( 'Appointment', 'resox' ),
			)
		);

		$this->add_control(
			'appointment_on_off',
			array(
				'label'        => esc_html__( 'Enable', 'resox-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'your-plugin' ),
				'label_off'    => __( 'No', 'your-plugin' ),
				'return_value' => '1',
				'default'      => false,
			)
		);

		$this->add_control(
			'appointment_heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Timings', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_day',
			array(
				'label'       => esc_html__( 'Day', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discover More', 'resox-core' ),
			)
		);

		$repeater->add_control(
			'item_time',
			array(
				'label'       => esc_html__( 'Time', 'resox-core' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discover More', 'resox-core' ),
			)
		);

		$this->add_control(
			'appointment_items',
			array(
				'label'   => esc_html__( 'Item List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'item_day'  => esc_html__( 'MON', 'resox-core' ),
						'item_time' => esc_html__( '9:00am - 6:00pm', 'resox-core' ),
					),
					array(
						'item_day'  => esc_html__( 'FRI TO SAT', 'resox-core' ),
						'item_time' => esc_html__( '10:00am - 4:00pm', 'resox-core' ),
					),
					array(
						'item_day'  => esc_html__( 'SUN', 'resox-core' ),
						'item_time' => esc_html__( 'Work off', 'resox-core' ),
					),
				),
			)
		);

		$this->add_control(
			'appointment_button_label',
			array(
				'label'   => esc_html__( 'Label', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Timings', 'resox' ),
			)
		);

		$this->add_control(
			'appointment_button_link',
			array(
				'label'         => esc_html__( 'Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'footer_bottom',
			array(
				'label'     => esc_html__( 'Footer Bottom', 'resox' ),
				'condition' => array( 'footer_bottom_on_off' => '1' ),
			)
		);

		$this->add_control(
			'footer_copyright',
			array(
				'label'   => esc_html__( 'Copyright Text', 'resox' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( '© Copyright 2020 by <a href="index.html">Resox</a>', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'footer_item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox-core' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$repeater->add_control(
			'footer_item_link',
			array(
				'label'         => esc_html__( 'Link', 'resox-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'footer_items',
			array(
				'label'   => esc_html__( 'Item List', 'resox-core' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'footer_item_icon' => esc_html__( 'MON', 'resox-core' ),
						'footer_item_link' => esc_html__( '9:00am - 6:00pm', 'resox-core' ),
					),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'backgrounds',
			array(
				'label' => esc_html__( 'Backgrounds', 'resox' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bg_img',
			array(
				'label'   => esc_html__( 'Background', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);
		$this->add_control(
			'bg_icon',
			array(
				'label'   => esc_html__( 'Background Icon', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->end_controls_section();

		resox_public_header_control( $this, 'h4' );

		resox_public_content_control( $this );

	}
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Column System
		$links_on_off       = $settings['links_on_off'];
		$services_on_off    = $settings['services_on_off'];
		$appointment_on_off = $settings['appointment_on_off'];

		if ( $links_on_off && $services_on_off && $appointment_on_off ) {
			$global_column_class = 'col-lg-3';
		} else {
			$global_column_class = 'col-lg';
		}

		// Column System

		$footer_bottom_on_off = $settings['footer_bottom_on_off'];
		// From Public Header
		$public_title_tag = $settings['public_title_tag'];

		$links_heading = $settings['links_heading'];
		$this->add_render_attribute( 'links_heading', 'class', 'typo-title-text' );
		$this->add_inline_editing_attributes( 'links_heading', 'none' );

		$services_heading = $settings['services_heading'];
		$this->add_render_attribute( 'services_heading', 'class', 'typo-title-text' );
		$this->add_inline_editing_attributes( 'services_heading', 'none' );

		$appointment_heading = $settings['appointment_heading'];
		$this->add_render_attribute( 'appointment_heading', 'class', 'typo-title-text' );
		$this->add_inline_editing_attributes( 'appointment_heading', 'none' );

		$content = $settings['content'];
		$this->add_render_attribute( 'content', 'class', 'typo-content-text' );
		$this->add_inline_editing_attributes( 'content', 'none' );
		// From Public Header
		$links_menu    = $settings['links_menu'];
		$services_menu = $settings['services_menu'];

		$contact_icon  = $settings['contact_icon'];
		$contact_label = $settings['contact_label'];
		$this->add_render_attribute( 'contact_label', 'class', 'typo-content-text' );
		$this->add_inline_editing_attributes( 'contact_label', 'none' );
		$contact_number   = $settings['contact_number'];
		$footer_copyright = $settings['footer_copyright'];
		$this->add_render_attribute( 'footer_copyright', 'class', 'typo-content-text' );
		$this->add_inline_editing_attributes( 'footer_copyright', 'none' );
		$tel                      = str_replace( ' ', '', $contact_number );
		$appointment_button_label = $settings['appointment_button_label'];

		$bg_img = ( $settings['bg_img']['id'] != '' ) ? wp_get_attachment_image_url( $settings['bg_img']['id'], 'full' ) : $settings['bg_img']['url'];

		$bg_icon = ( $settings['bg_icon']['id'] != '' ) ? wp_get_attachment_image_url( $settings['bg_icon']['id'], 'full' ) : $settings['bg_icon']['url'];
		if ( ! empty( $bg_icon ) ) {
			$this->add_render_attribute( 'bg_icon', 'src', $bg_icon );
			$this->add_render_attribute( 'bg_icon', 'alt', \Elementor\Control_Media::get_image_alt( $settings['bg_icon'] ) );
			$this->add_render_attribute( 'bg_icon', 'title', \Elementor\Control_Media::get_image_title( $settings['bg_icon'] ) );
			$settings['bg_icon_size'] = 'full';
			$bg_icon_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'bg_icon' );
		}

		$logo_img = ( $settings['logo_img']['id'] != '' ) ? wp_get_attachment_image_url( $settings['logo_img']['id'], 'full' ) : $settings['logo_img']['url'];
		if ( ! empty( $logo_img ) ) {
			$this->add_render_attribute( 'logo_img', 'src', $logo_img );
			$this->add_render_attribute( 'logo_img', 'alt', \Elementor\Control_Media::get_image_alt( $settings['logo_img'] ) );
			$this->add_render_attribute( 'logo_img', 'title', \Elementor\Control_Media::get_image_title( $settings['logo_img'] ) );
			$settings['logo_img_size'] = 'full';
			$logo_img_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'logo_img' );
		}

		$item_menu_link     = $settings['appointment_button_link'];
		$item_menu_target   = $settings['appointment_button_link']['is_external'] ? ' target="_blank"' : '';
		$item_menu_nofollow = $settings['appointment_button_link']['nofollow'] ? ' rel="nofollow"' : '';
		?>
<!-- main-footer -->
<footer class="main-footer">
	<div class="footer-top" style="background-image: url(<?php echo $bg_img; ?>);">
		<figure class="icon-layer"><?php echo $bg_icon_html; ?></figure>
		<div class="auto-container">
			<div class="widget-section">
				<div class="row clearfix">
					<div class="<?php echo $global_column_class; ?> col-md-6 col-sm-12 footer-column">
						<div class="footer-widget logo-widget">
							<figure class="logo-box"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo $logo_img_html; ?></a></figure>
							<div class="text">
								<p <?php echo $this->get_render_attribute_string( 'content' ); ?>>
									<?php echo $content; ?></p>
							</div>
							<ul class="info clearfix">

								<?php
									$i = 1;
								foreach ( $settings['items'] as $item ) {
									$item_name = $item['item_name'];
									$item_icon = $item['item_icon'];
									$item_link = $item['item_link']['url'];
									if ( ! empty( $item_link ) ) {
										$this->add_render_attribute( 'item_link' . $i, 'href', $item_link );
										$this->add_render_attribute( 'item_link' . $i, 'class', '' );
										if ( $item['item_link']['is_external'] ) {
											$this->add_render_attribute( 'item_link' . $i, 'target', '_blank' );
										}
										if ( ! empty( $item['item_link']['nofollow'] ) ) {
											$this->add_render_attribute( 'item_link' . $i, 'rel', 'nofollow' );
										}
									}
									?>
								<li><?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?>
									<?php if ( $item_link ) : ?>
									<a
										<?php echo $this->get_render_attribute_string( 'item_link' . $i ); ?>><?php echo $item_name; ?></a>
										<?php
									else :
										?>
									<?php echo $item_name; ?> <?php endif; ?>
								</li>
									<?php
									$i++; }
								?>
							</ul>
							<div class="support-box">
								<?php \Elementor\Icons_Manager::render_icon( ( $contact_icon ), array( 'aria-hidden' => 'true' ) ); ?>
								<p <?php echo $this->get_render_attribute_string( 'contact_label' ); ?>>
									<?php echo $contact_label; ?></p>
								<h5><a href="tel:<?php echo $tel; ?>"><?php echo $contact_number; ?></a></h5>
							</div>
						</div>
					</div>
					<?php if ( $links_on_off ) : ?>
					<div class="<?php echo $global_column_class; ?> col-md-6 col-sm-12 footer-column">
						<div class="footer-widget links-widget ml-70">
							<div class="widget-title">
								<!-- Title -->
								<<?php echo $public_title_tag; ?>
									<?php echo $this->get_render_attribute_string( 'links_heading' ); ?>>
									<?php echo $links_heading; ?>
								</<?php echo $public_title_tag; ?>>
								<!-- Title -->
							</div>
							<div class="widget-content">
								<ul class="links-list clearfix">
									<?php
									$menu     = $links_menu;
									$menulist = wp_get_nav_menu_items( $menu, $args = array() );
									if ( $menulist ) :
										foreach ( $menulist as $navItem ) {
											echo '<li><a href="' . $navItem->url . '" title="' . $navItem->title . '">' . $navItem->title . '</a></li>';
										}
									endif;
									?>
								</ul>
							</div>
						</div>
					</div>
						<?php
					endif;
					if ( $services_on_off ) :
						?>
					<div class="<?php echo $global_column_class; ?> col-md-6 col-sm-12 footer-column">
						<div class="footer-widget links-widget">
							<div class="widget-title">
								<!-- Title -->
								<<?php echo $public_title_tag; ?>
									<?php echo $this->get_render_attribute_string( 'services_heading' ); ?>>
									<?php echo $services_heading; ?>
								</<?php echo $public_title_tag; ?>>
								<!-- Title -->
							</div>
							<div class="widget-content">
								<ul class="links-list clearfix">
									<?php
									$menu     = $services_menu;
									$menulist = wp_get_nav_menu_items( $menu, $args = array() );
									if ( $menulist ) :
										foreach ( $menulist as $navItem ) {
											echo '<li><a href="' . $navItem->url . '" title="' . $navItem->title . '">' . $navItem->title . '</a></li>';
										}
									endif;
									?>
								</ul>
							</div>
						</div>
					</div>
						<?php
					endif;
					if ( $appointment_on_off ) :
						?>
					<div class="<?php echo $global_column_class; ?> col-md-6 col-sm-12 footer-column">
						<div class="footer-widget appointment-widget centred">
							<div class="icon-layer"><i class="flaticon-alarm-clock-1"></i></div>
							<div class="widget-title">
								<!-- Title -->
								<<?php echo $public_title_tag; ?>
									<?php echo $this->get_render_attribute_string( 'appointment_heading' ); ?>>
									<?php echo $appointment_heading; ?>
								</<?php echo $public_title_tag; ?>>
								<!-- Title -->
							</div>
							<div class="widget-content">
								<ul class="shediul-list clearfix">
									<?php
									$i = 1;
									foreach ( $settings['appointment_items'] as $item ) {
										$item_day  = $item['item_day'];
										$item_time = $item['item_time'];
										?>
									<li>
										<span><?php echo $item_day; ?></span>
										<h6><?php echo $item_time; ?></h6>
									</li>
										<?php
										$i++; }
									?>
									<li>
										<a class="theme-btn-one" href="<?php echo esc_url( $item_menu_link['url'] ); ?>"
											<?php echo $item_menu_target . ' ' . $item_menu_nofollow; ?>><?php echo $appointment_button_label; ?></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
		<?php if ( $footer_bottom_on_off ) : ?>
	<div class="footer-botton">
		<div class="auto-container clearfix">
			<div class="copyright pull-left">
				<p <?php echo $this->get_render_attribute_string( 'footer_copyright' ); ?>>
					<?php echo $footer_copyright; ?></p>
			</div>
			<ul class="social-links pull-right clearfix">

				<?php
				$i = 1;
				foreach ( $settings['footer_items'] as $item ) {
					$footer_item_icon = $item['footer_item_icon'];

					$footer_item_link = $item['footer_item_link']['url'];
					if ( ! empty( $footer_item_link ) ) {
						$this->add_render_attribute( 'footer_item_link' . $i, 'href', $footer_item_link );
						$this->add_render_attribute( 'footer_item_link' . $i, 'class', '' );
						if ( $item['footer_item_link']['is_external'] ) {
							$this->add_render_attribute( 'footer_item_link' . $i, 'target', '_blank' );
						}
						if ( ! empty( $item['footer_item_link']['nofollow'] ) ) {
							$this->add_render_attribute( 'footer_item_link' . $i, 'rel', 'nofollow' );
						}
					}
					?>
				<li><a
						<?php echo $this->get_render_attribute_string( 'footer_item_link' . $i ); ?>><?php \Elementor\Icons_Manager::render_icon( ( $footer_item_icon ), array( 'aria-hidden' => 'true' ) ); ?></a>
				</li>
					<?php
					$i++; }
				?>

			</ul>
		</div>
	</div>
	<?php endif; ?>
</footer>
<!-- main-footer end -->
		<?php
	}

	protected function _content_template() {
	}
}
