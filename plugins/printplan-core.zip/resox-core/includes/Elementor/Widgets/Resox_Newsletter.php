<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use \Resox\Helper\Elementor\Settings\Header;
use Elementor\Core\Schemes;
class Resox_Newsletter extends Widget_Base
{




	public function get_name()
	{
		return 'resox_newsletter';
	}

	public function get_title()
	{
		return esc_html__('Resox Newsletter', 'resox');
	}

	public function get_icon()
	{
		return 'sds-widget-ico';
	}


	public function get_categories()
	{
		return array('resox');
	}

	protected function _register_controls()
	{

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__('general', 'resox'),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => esc_html__('Title', 'resox'),
				'type'    => Controls_Manager::TEXT,
				'default' => __('Subscribe our newsletter', 'resox'),
			)
		);
		$this->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'Html Tag', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'h1'   => esc_html__( 'H1', 'resox-core' ),
					'h2'   => esc_html__( 'H2', 'resox-core' ),
					'h3'   => esc_html__( 'H3', 'resox-core' ),
					'h4'   => esc_html__( 'H4', 'resox-core' ),
					'h5'   => esc_html__( 'H5', 'resox-core' ),
					'h6'   => esc_html__( 'H6', 'resox-core' ),
					'div'  => esc_html__( 'div', 'resox-core' ),
					'span' => esc_html__( 'span', 'resox-core' ),
					'p'    => esc_html__( 'p', 'resox-core' ),
				),
				'default' => 'h3',

			)
		);
		$this->add_control(
			'newsletter_cf7',
			array(
				'label'   => esc_html__('Select Contact Form', 'firbrigs-core'),
				'type'    => Controls_Manager::SELECT,
				'options' => Header::getContactForm7Posts(),
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'text_style_section',
			array(
				'label' => __( 'Text Style', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'resox-core' ),
				'scheme'   => Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .newsletter_heading',
			)
		);
		$this->end_controls_section();
	}
	protected function render()
	{
		$settings                 = $this->get_settings_for_display();
		$title                    = $settings['title'];
		$html_tag                    = $settings['html_tag'];
?> 
		<section class="cta-style-two">
			<div class="auto-container">
				<div class="inner-container bg-color-2">
					<div class="row clearfix">
						<div class="col-lg-4 col-md-12 col-sm-12 text-column">
							<div class="text">
								<i class="flaticon-email"></i>
								<<?php echo $html_tag; ?> class="newsletter_heading"><?php echo $title; ?></<?php echo $html_tag; ?>>
							</div>
						</div>
						<div class="col-lg-8 col-md-12 col-sm-12 form-column">
							<div class="subscribe-form">
								<?php
								if ($settings['newsletter_cf7']) :
									echo do_shortcode('[contact-form-7 id="' . $settings['newsletter_cf7'] . '"]');
								endif;
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
<?php
	}

	protected function _content_template()
	{
	}
}
