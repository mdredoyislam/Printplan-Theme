<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;
use Elementor\Core\Schemes;

class Resox_Certified extends Widget_Base {

	public function get_name() {
		return 'resox_certified';
	}

	public function get_title() {
		return esc_html__( 'Resox Certified', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'general', 'resox' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'We’re Certified Physiotherapy Clinic', 'resox' ),
			)
		);
		$this->add_control(
			'html_tag',
			array(
				'label'   => esc_html__( 'Html Tag', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'h1'   => esc_html__( 'H1', 'resox-core' ),
					'h2'   => esc_html__( 'H2', 'resox-core' ),
					'h3'   => esc_html__( 'H3', 'resox-core' ),
					'h4'   => esc_html__( 'H4', 'resox-core' ),
					'h5'   => esc_html__( 'H5', 'resox-core' ),
					'h6'   => esc_html__( 'H6', 'resox-core' ),
					'div'  => esc_html__( 'div', 'resox-core' ),
					'span' => esc_html__( 'span', 'resox-core' ),
					'p'    => esc_html__( 'p', 'resox-core' ),
				),
				'default' => 'h3',

			)
		);

		$this->add_control(
			'content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Lorem ipsum dolor sit amet, notted elit sed do eius mod tempor incididunt ut labore et.', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'video_image',
			array(
				'label'   => esc_html__( 'Video Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$this->add_control(
			'video_link',
			array(
				'label'         => esc_html__( 'Video Link', 'resox' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'patients_count',
			array(
				'label'   => esc_html__( 'Patients Count', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '34560', 'resox' ),
			)
		);

		$this->add_control(
			'patients_text',
			array(
				'label'   => esc_html__( 'Patients Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Happy and healthy patients', 'resox' ),
			)
		);

		$this->add_control(
			'shediul_title',
			array(
				'label'   => esc_html__( 'Shediul Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Timings', 'resox' ),
			)
		);

		$this->add_control(
			'shediul_time',
			array(
				'label'       => esc_html__( 'Shediul Time', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( '', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'   => esc_html__( 'Button Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Book Appointment', 'resox' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'text_style_section',
			array(
				'label' => __( 'Text Style', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'content_typography',
				'label'    => __( 'Typography', 'resox-core' ),
				'scheme'   => Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .certified_heading',
			)
		);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$title    = $settings['title'];
		$content  = $settings['content'];
		$html_tag  = $settings['html_tag'];
		$image    = ( $settings['image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['image']['id'], 'full' ) : $settings['image']['url'];
		if ( ! empty( $image ) ) {
			$this->add_render_attribute( 'image', 'src', $image );
			$this->add_render_attribute( 'image', 'alt', \Elementor\Control_Media::get_image_alt( $settings['image'] ) );
			$this->add_render_attribute( 'image', 'title', \Elementor\Control_Media::get_image_title( $settings['image'] ) );
			$settings['image_size'] = 'full';
			$image_html             = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'image' );

		}
		$video_image    = ( $settings['video_image']['id'] != '' ) ? wp_get_attachment_image_url( $settings['video_image']['id'], 'full' ) : $settings['video_image']['url'];
		$video_link     = $settings['video_link']['url'];
		$patients_count = $settings['patients_count'];
		$patients_text  = $settings['patients_text'];
		$shediul_title  = $settings['shediul_title'];
		$shediul_time   = $settings['shediul_time'];
		$button_text    = $settings['button_text'];
		$button_link    = $settings['button_link']['url'];
		if ( ! empty( $button_link ) ) {
			$this->add_render_attribute( 'button_link', 'href', $button_link );
			if ( ! empty( $settings['button_link']['is_external'] ) ) {
				$this->add_render_attribute( 'button_link', 'target', '_blank' );
			}

			if ( ! empty( $settings['button_link']['nofollow'] ) ) {
				$this->add_render_attribute( 'button_link', 'rel', 'nofollow' );
			}
		}
		?>
<section class="certified-section">
	<div class="auto-container">
		<div class="inner-container">
			<div class="row clearfix">
				<div class="col-lg-9 col-md-12 col-sm-12 content-column">
					<div id="content_block_5">
						<div class="content-box mr-30">
							<?php if ( $image ) : ?>
							<figure class="image-box"><?php echo $image_html; ?></figure>
							<?php endif; ?>
							<div class="inner-box">
								<<?php echo $html_tag; ?> class="certified_heading"><?php echo $title; ?></<?php echo $html_tag; ?>>
								<p><?php echo $content; ?></p>
								<div class="inner">
									<div class="video-inner"
										style="background-image: url(<?php echo esc_url( $video_image ); ?>);">
										<a href="<?php echo $video_link; ?>" class="lightbox-image video-btn"
											data-caption=""><i class="fas fa-play"></i></a>
									</div>
									<div class="counter-block">
										<div class="count-outer count-box">
											<span class="count-text" data-speed="1500"
												data-stop="<?php echo $patients_count; ?>">0</span>
										</div>
										<h5><?php echo $patients_text; ?></h5>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-12 col-sm-12 inner-column">
					<div id="content_block_6">
						<div class="content-box centred bg-color-3">
							<div class="icon-layer"><i class="flaticon-alarm-clock-1"></i></div>
							<h4><?php echo $shediul_title; ?></h4>
							<ul class="shediul-list clearfix">
								<?php echo $shediul_time; ?>
								<li>
									<a <?php echo $this->get_render_attribute_string( 'button_link' ); ?>
										class="theme-btn-one"><?php echo $button_text; ?></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		<?php
	}

	protected function _content_template() {
	}
}
