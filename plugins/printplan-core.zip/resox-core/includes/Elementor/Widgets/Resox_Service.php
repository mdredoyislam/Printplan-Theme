<?php
namespace Resox\Helper\Elementor\Widgets;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use \Elementor\Repeater;

require 'Service_Skin_One.php';
require 'Service_Skin_Slide.php';
class Resox_Service extends Widget_Base {

	public function get_name() {
		return 'resox_service';
	}

	public function get_title() {
		return esc_html__( 'Resox Service', 'resox' );
	}

	public function get_icon() {
		return 'sds-widget-ico';
	}

	public function get_categories() {
		return array( 'resox' );
	}
	public function get_script_depends() {
		return array( 'service_js' );
	}
	

	protected function _register_skins() {
		$this->add_skin( new Skin_Classic( $this ) );
		$this->add_skin( new Skin_Slider_Service( $this ) );
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'General', 'resox' ),
			)
		);
		$this->add_control(
			'layout_style',
			array(
				'label'   => esc_html__( 'Layout Style', 'resox-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'style_1' => esc_html__( 'Style One', 'resox-core' ),
					'style_2' => esc_html__( 'Style Two', 'resox-core' ),
				),
				'default' => 'style_1',
			)
		);
		$this->add_control(
			'tagline',
			array(
				'label'   => esc_html__( 'Tagline', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Our Services', 'resox' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'What We’re Offering', 'resox' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item',
			array(
				'label' => esc_html__( 'ITEM', 'resox' ),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Massage Therapy', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'       => esc_html__( 'Content', 'resox' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Lorem is free text no used by other agencies...', 'resox' ),
				'placeholder' => esc_html__( 'Type your description here', 'resox' ),

			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Image', 'resox' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),

			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label' => esc_html__( 'Icon', 'resox' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$repeater->add_control(
			'item_button_text',
			array(
				'label'   => esc_html__( 'Button Text', 'resox' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Read More', 'resox' ),
			)
		);

		$repeater->add_control(
			'item_button_link',
			array(
				'label'         => esc_html__( 'Button Link', 'resox' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'resox' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);

		$this->add_control(
			'items',
			array(
				'label'   => esc_html__( 'Repeater List', 'resox' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array(
						'list_title'   => esc_html__( 'Title #1', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
					array(
						'list_title'   => esc_html__( 'Title #2', 'resox' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'resox' ),
					),
				),
			)
		);

		$this->end_controls_section();
		resox_public_header_control( $this,'h2' );

	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$layout_style = $settings['layout_style'];
		$tagline      = $settings['tagline'];
		$heading      = $settings['heading'];
		$public_title_tag      = $settings['public_title_tag'];

		if ( $layout_style == 'style_2' ) {
			$layout_style = 'service-style-two sec-pad';
			$title_class  = 'sec-title light';
		} else {
			$layout_style = 'service-section sec-pad border-bottom';
			$title_class  = 'sec-title';
		}
		?>
<section class="<?php echo esc_attr( $layout_style ); ?>">
	<div class="auto-container">
		<div class="<?php echo esc_attr( $title_class ); ?>">
			<p><?php echo $tagline; ?></p>
			<<?php echo $public_title_tag; ?> class="typo-title-text">
				<?php echo $heading; ?>
			</<?php echo $public_title_tag; ?>>
		</div>
		<div class="four-item-carousel owl-carousel owl-theme owl-dots-none">
			<?php
			$i = 1;
			foreach ( $settings['items'] as $item ) {
				$item_title   = $item['item_title'];
				$item_content = $item['item_content'];
				$item_image   = ( $item['item_image']['id'] != '' ) ? wp_get_attachment_image_url( $item['item_image']['id'], 'full' ) : $item['item_image']['url'];
				if ( ! empty( $item_image ) ) {
					$this->add_render_attribute( 'item_image', 'src', $item_image );
					$this->add_render_attribute( 'item_image', 'alt', \Elementor\Control_Media::get_image_alt( $item['item_image'] ) );
					$this->add_render_attribute( 'item_image', 'title', \Elementor\Control_Media::get_image_title( $item['item_image'] ) );
					$item['item_image_size'] = 'full';
					$item_image_html         = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $item, 'item_image' );
				}
				$item_icon        = $item['item_icon'];
				$item_button_text = $item['item_button_text'];
				$item_button_link = $item['item_button_link']['url'];
				?>
			<div class="service-block-one">
				<div class="inner-box">
					<div class="image-box">
						<figure class="image"><a
								href="<?php echo $item_button_link; ?>"><?php echo $item_image_html; ?></a></figure>
						<div class="icon-box">
							<?php \Elementor\Icons_Manager::render_icon( ( $item_icon ), array( 'aria-hidden' => 'true' ) ); ?>
						</div>
					</div>
					<div class="lower-content">
						<h4><a href="<?php echo $item_button_link; ?>"><?php echo $item_title; ?></a></h4>
						<p><?php echo $item_content; ?></p>
						<div class="link"><a href="<?php echo $item_button_link; ?>"><i
									class="fas fa-chevron-circle-right"></i><?php echo $item_button_text; ?></a></div>
					</div>
				</div>
			</div>
				<?php
				$i++;
			}
			?>


		</div>
	</div>
</section>
		<?php
	}

	protected function _content_template() {
	}
}
