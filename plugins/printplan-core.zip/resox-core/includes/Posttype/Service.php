<?php
namespace resox\Helper\Posttype;

class Service {



	/**
	 * Initialize the class
	 */
	function __construct() {
		// Register the post type
		add_action( 'init', array( $this, 'resox_services_post_type' ), 0 );
	}

	// Register Custom Post Type
	function resox_services_post_type() {

		$labels = array(
			'name'                  => _x( 'Services', 'Post Type General Name', 'resox-core' ),
			'singular_name'         => _x( 'Service', 'Post Type Singular Name', 'resox-core' ),
			'menu_name'             => __( 'Service', 'resox-core' ),
			'name_admin_bar'        => __( 'Service', 'resox-core' ),
			'archives'              => __( 'Item Archives', 'resox-core' ),
			'parent_item_colon'     => __( 'Parent Item:', 'resox-core' ),
			'all_items'             => __( 'All Service', 'resox-core' ),
			'add_new_item'          => __( 'Add New Service', 'resox-core' ),
			'add_new'               => __( 'Add New Service', 'resox-core' ),
			'new_item'              => __( 'New Service Item', 'resox-core' ),
			'edit_item'             => __( 'Edit Service Item', 'resox-core' ),
			'update_item'           => __( 'Update Service Item', 'resox-core' ),
			'view_item'             => __( 'View Service Item', 'resox-core' ),
			'search_items'          => __( 'Search Item', 'resox-core' ),
			'not_found'             => __( 'Not found', 'resox-core' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'resox-core' ),
			'featured_image'        => __( 'Featured Image', 'resox-core' ),
			'set_featured_image'    => __( 'Set featured image', 'resox-core' ),
			'remove_featured_image' => __( 'Remove featured image', 'resox-core' ),
			'use_featured_image'    => __( 'Use as featured image', 'resox-core' ),
			'insert_into_item'      => __( 'Insert into item', 'resox-core' ),
			'uploaded_to_this_item' => __( 'Uploaded to this item', 'resox-core' ),
			'items_list'            => __( 'Items list', 'resox-core' ),
			'items_list_navigation' => __( 'Items list navigation', 'resox-core' ),
			'filter_items_list'     => __( 'Filter items list', 'resox-core' ),
		);

		$args = array(
			'labels'             => $labels,
			'description'        => __( 'Description.', 'resox-core' ),
			'public'             => true,
			'publicly_queryable' => true,
			'taxonomies'         => array( 'taxonomy_service' ),
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'service' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		);

		register_post_type( 'service', $args );
	}
}
