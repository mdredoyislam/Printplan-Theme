<?php
namespace Resox\Helper;

/**
 * The admin class
 */
class Posttype {




	/**
	 * Initialize the class
	 */
	function __construct() {
		// new Posttype\Service();
	}
}
