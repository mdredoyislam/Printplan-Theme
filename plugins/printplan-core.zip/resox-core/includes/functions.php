<?php
// Silence is golden.

function resox_post_thumbnail_image( $size = 'full' ) {
	 $resox_featured_image_url = get_the_post_thumbnail_url( get_the_ID(), 'resox_galleries_home' );
	?>
<picture>
	<source type="image/jpeg" srcset="<?php echo esc_url( $resox_featured_image_url ); ?>">
	<img src="<?php echo esc_url( $resox_featured_image_url ); ?>" alt="<?php esc_attr_e( 'Img', 'leganic' ); ?>">
</picture>
	<?php
}
/**
 * Strip all the tags except allowed html tags
 *
 * The name is based on inline editing toolbar name
 *
 * @param  string $string
 * @return string
 */
function resox_kses_basic( $string = '' ) {
	 return wp_kses( $string, resox_get_allowed_html_tags( 'basic' ) );
}

/**
 * Strip all the tags except allowed html tags
 *
 * The name is based on inline editing toolbar name
 *
 * @param  string $string
 * @return string
 */
function resox_kses_intermediate( $string = '' ) {
	return wp_kses( $string, resox_get_allowed_html_tags( 'intermediate' ) );
}

function resox_get_allowed_html_tags( $level = 'basic' ) {
	$allowed_html = array(
		'b'      => array(),
		'i'      => array(),
		'u'      => array(),
		'em'     => array(),
		'br'     => array(),
		'abbr'   => array(
			'title' => array(),
		),
		'span'   => array(
			'class' => array(),
		),
		'strong' => array(),
	);

	if ( $level === 'intermediate' ) {
		$allowed_html['a'] = array(
			'href'  => array(),
			'title' => array(),
			'class' => array(),
			'id'    => array(),
		);
	}

	return $allowed_html;
}


function videocafe_sc_heading( $atts, $content = null ) {
	extract(
		shortcode_atts(
			array(
				'title_text' => '',
			),
			$atts,
			'heading'
		)
	);

	return '<h4 class="widget_title">' . $title_text . '</h4>';
}
add_shortcode( 'heading', 'videocafe_sc_heading' );


add_shortcode( 'videocafe-category-checklist', 'videocafe_category_checklist' );
function videocafe_category_checklist( $atts ) {
	// process passed arguments or assign WP defaults
	$atts = shortcode_atts(
		array(
			'post_id'              => 0,
			'descendants_and_self' => 0,
			'selected_cats'        => false,
			'popular_cats'         => false,
			'checked_ontop'        => true,
		),
		$atts,
		'videocafe-category-checklist'
	);

	// string to bool conversion, so the bool params work as expected
	$atts['selected_cats'] = to_bool( $atts['selected_cats'] );
	$atts['popular_cats']  = to_bool( $atts['popular_cats'] );
	$atts['checked_ontop'] = to_bool( $atts['checked_ontop'] );

	// load template.php from admin, where wp_category_checklist() is defined
	include_once ABSPATH . '/wp-admin/includes/template.php';

	// generate the checklist
	ob_start();
	?>
<div class="categorydiv">
	<ul class="category-tabs">
		<div id="taxonomy-category" class="categorydiv">
			<div id="category-all" class="tabs-panel">
				<ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
					<?php
					wp_category_checklist(
						$atts['post_id'],
						$atts['descendants_and_self'],
						$atts['selected_cats'],
						$atts['popular_cats'],
						null,
						$atts['checked_ontop']
					);
					?>
				</ul>
			</div>
		</div>
	</ul>
</div>

	<?php
	return ob_get_clean();
}
function to_bool( $bool ) {
	 return ( is_bool( $bool ) ? $bool : ( is_numeric( $bool ) ? ( (bool) intval( $bool ) ) : $bool !== 'false' ) );
}
if ( ! function_exists( 'resox_options' ) ) :

	function cameron_options() {
		global $cameron_options;
		$opt_pref = 'cameron_';
		if ( empty( $cameron_options ) ) {
			$cameron_options = get_option( $opt_pref . 'options' );
		}
		return $cameron_options;
	}
endif;

if ( ! function_exists( 'resox_public_tagline_control' ) ) {
	function resox_public_tagline_control( $obj ) {
		$obj->start_controls_section(
			'public_tagline_typography',
			array(
				'label' => __( 'Tagline', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$obj->add_control(
			'public_tagline_tag',
			array(
				'label'   => __( 'Header Tag', 'resox-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
				),
				'default' => 'h2',
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_tagline_typography',
				'label'    => __( 'Tagline', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-tagline-text',
			)
		);

		$obj->add_control(
			'public_tagline_color',
			array(
				'label'     => __( 'Tagline Color', 'resox-core' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-tagline-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->end_controls_section();
	}
}

if ( ! function_exists( 'resox_public_header_control' ) ) {
	function resox_public_header_control( $obj, $dflt ) {
		$obj->start_controls_section(
			'public_title_typography',
			array(
				'label' => __( 'Title', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$obj->add_control(
			'public_title_tag',
			array(
				'label'   => __( 'Header Tag', 'resox-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
				),
				'default' => $dflt,
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_title_typography',
				'label'    => __( 'Title', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-title-text',
			)
		);

		$obj->add_control(
			'public_title_color',
			array(
				'label'     => __( 'Title Color', 'resox-core' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-title-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->end_controls_section();
	}
}


if ( ! function_exists( 'resox_public_content_control' ) ) {
	function resox_public_content_control( $obj ) {
		$obj->start_controls_section(
			'public_desc_typography',
			array(
				'label' => __( 'Content', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_desc_typography',
				'label'    => __( 'Description', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-content-text',
			)
		);

		$obj->add_control(
			'public_desc_color',
			array(
				'label'     => __( 'Description Color', 'resox-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-content-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->end_controls_section();
	}
}


if ( ! function_exists( 'resox_public_item_control' ) ) {
	function resox_public_item_control( $obj ) {
		$obj->start_controls_section(
			'public_item_typography',
			array(
				'label' => __( 'Items', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_item_title_typography',
				'label'    => __( 'Title', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-item_title-text',
			)
		);

		$obj->add_control(
			'public_item_title_color',
			array(
				'label'     => __( 'Title Color', 'resox-core' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-item_title-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_item_content_typography',
				'label'    => __( 'Title', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-item_content-text',
			)
		);

		$obj->add_control(
			'public_item_content_color',
			array(
				'label'     => __( 'Title Color', 'resox-core' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-item_content-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->end_controls_section();
	}
}
function resox_images_size() {
	add_image_size( 'resox-blog-home', 370, 290, true );
	add_image_size( 'resox-blog-image-size', 370, 317, true );
}

add_action( 'after_setup_theme', 'resox_images_size' );

if ( ! function_exists( 'get_elementor_library' ) ) {
	function get_elementor_library() {
		$pageslist = get_posts(
			array(
				'post_type'      => 'elementor_library',
				'posts_per_page' => -1,
			)
		);
		$pagearray = array();
		if ( ! empty( $pageslist ) ) {
			foreach ( $pageslist as $page ) {
				$pagearray[ $page->ID ] = $page->post_title;
			}
		}
		return $pagearray;
	}
}
if ( ! function_exists( 'resox_public_header_control' ) ) {
	function resox_public_header_control( $obj ) {
		$obj->start_controls_section(
			'public_title_typography',
			array(
				'label' => __( 'Title', 'resox-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$obj->add_control(
			'public_title_tag',
			array(
				'label'   => __( 'Header Tag', 'resox-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
				),
				'default' => 'h2',
			)
		);

		$obj->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'public_title_typography',
				'label'    => __( 'Title', 'resox-core' ),
				'selector' => '{{WRAPPER}} .typo-title-text',
			)
		);

		$obj->add_control(
			'public_title_color',
			array(
				'label'     => __( 'Title Color', 'resox-core' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .typo-title-text' => 'color: {{VALUE}} !important',
				),
			)
		);

		$obj->end_controls_section();
	}
}

// css individual Load
add_filter( 'combine_vc_ele_css_pb_build_css_assets_css_path', 'resox_css_list' );
function resox_css_list( $product_css_path ) {
	$product_css_path = plugin_dir_path( __DIR__ ) . '/assets/elementor/css/';
	return $product_css_path;
}

add_filter( 'combine_vc_ele_css_pb_build_css_assets_css_url', 'resox_css_list_url' );
function resox_css_list_url() {
	 $product_css_path = plugin_dir_url( __DIR__ ) . '/assets/elementor/css/';
	return $product_css_path;
}

add_filter( 'combine_vc_ele_css_pb_sc_list_array', 'resox_array_list' );
function resox_array_list( $product_css_array ) {
	$product_css_array = array(
		'resox_banner_slider'  => array(
			'css'      => array( 'banner-slider' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_feature'        => array(
			'css'      => array( 'feature-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_about'          => array(
			'css'      => array( 'about-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_client'         => array(
			'css'      => array( 'clients-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_proudly'        => array(
			'css'      => array( 'proudly-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_feature_two'    => array(
			'css'      => array( 'feature-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_testimonial'    => array(
			'css'      => array( 'testimonial-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_startup'        => array(
			'css'      => array( 'startup-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_blog'           => array(
			'css'      => array( 'news-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_gallery'        => array(
			'css'      => array( 'gallery-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_call_to_action' => array(
			'css'      => array( 'call-to-action' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_welcome'        => array(
			'css'      => array( 'welcome' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_certified'      => array(
			'css'      => array( 'certified-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_about_two'      => array(
			'css'      => array( 'about-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_about_three'    => array(
			'css'      => array( 'weare-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_faq'            => array(
			'css'      => array( 'faq-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_team'           => array(
			'css'      => array( 'team-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_newsletter'     => array(
			'css'      => array( 'call-to-action' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_service'        => array(
			'css'      => array( 'service-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_service_single' => array(
			'css'      => array( 'service-details' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_team_details'   => array(
			'css'      => array( 'team-details' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_contact'        => array(
			'css'      => array( 'contact-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),
		'resox_team_slider'    => array(
			'css'      => array( 'team-section' ),
			'js'       => array(),
			'external' => array(
				'css' => array(),
				'js'  => array(),
			),
		),

	);
	return $product_css_array;
}
