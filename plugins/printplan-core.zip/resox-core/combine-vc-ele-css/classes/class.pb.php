<?php
namespace CVEC\classes\vc;

abstract class PBModule
{
    public static function init()
    {
    }

    public static function pb_sc_list_array()
    {
    }

    public static function get_pb_sc_array_list()
    {
    }

}
